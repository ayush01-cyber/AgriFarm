export class DocumentProcessor {
  static async extractTextFromFile(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      
      reader.onload = async (event) => {
        try {
          const text = event.target?.result;
          if (typeof text === 'string') {
            // Process the text to clean it up
            const cleanedText = this.cleanText(text);
            resolve(cleanedText);
          } else {
            reject(new Error('Failed to read file as text'));
          }
        } catch (error) {
          reject(new Error('Failed to process file'));
        }
      };
      
      reader.onerror = () => {
        reject(new Error('Failed to read file'));
      };
      
      // Read as text for supported formats
      reader.readAsText(file);
    });
  }

  private static cleanText(text: string): string {
    return text
      // Remove extra whitespace
      .replace(/\s+/g, ' ')
      // Remove special characters that might interfere with processing
      .replace(/[^\w\s.,!?-]/g, ' ')
      // Normalize line endings
      .replace(/\r\n|\r|\n/g, '\n')
      // Remove multiple line breaks
      .replace(/\n\s*\n/g, '\n')
      .trim();
  }

  static async processDocument(file: File): Promise<string> {
    try {
      const text = await this.extractTextFromFile(file);
      
      // Split into chunks if text is too long (OpenAI has token limits)
      const chunks = this.splitIntoChunks(text, 10000); // Assuming average of 4 chars per token
      
      return chunks[0]; // For now, just return the first chunk. In production, you'd want to handle multiple chunks
    } catch (error) {
      console.error('Error processing document:', error);
      throw new Error('Failed to process document');
    }
  }

  private static splitIntoChunks(text: string, chunkSize: number): string[] {
    const chunks: string[] = [];
    let startIndex = 0;
    
    while (startIndex < text.length) {
      let endIndex = startIndex + chunkSize;
      
      // Try to end at a sentence boundary
      if (endIndex < text.length) {
        const nextPeriod = text.indexOf('.', endIndex);
        if (nextPeriod !== -1 && nextPeriod - endIndex < 100) {
          endIndex = nextPeriod + 1;
        }
      }
      
      chunks.push(text.slice(startIndex, endIndex));
      startIndex = endIndex;
    }
    
    return chunks;
  }
}
