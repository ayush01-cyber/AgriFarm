// Agriculture-friendly color palette
export const colors = {
  primary: '#2e7d32', // Deep forest green
  secondary: '#795548', // Earth brown
  accent: '#8bc34a', // Light leaf green
  background: '#f1f8e9', // Light sage
  text: '#33691e', // Dark green
  textLight: '#558b2f', // Medium green
  warning: '#ff8f00', // Warm orange
  success: '#33691e', // Deep green
  surface: '#ffffff',
  border: '#c5e1a5',
  primaryLight: '#8bc34a'
};