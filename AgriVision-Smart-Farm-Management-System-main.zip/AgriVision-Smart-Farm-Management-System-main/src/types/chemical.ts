export interface ChemicalType {
  id: string;
  name: string;
  examples: string[];
  hazardLevel: 'low' | 'medium' | 'high';
  commonCrops: string[];
  weatherConsiderations: {
    temperature: string;
    humidity: string;
    windSpeed: string;
  };
}

export interface StorageGuideline {
  id: string;
  title: string;
  guidelines: string[];
}

export interface ApplicationGuideline {
  id: string;
  title: string;
  steps: string[];
}

export interface ProtectiveMeasure {
  item: string;
  required: boolean;
}
