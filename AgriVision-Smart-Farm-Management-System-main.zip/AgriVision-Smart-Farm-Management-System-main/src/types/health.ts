export interface HealthTab {
  id: string;
  label: string;
  component: React.ComponentType;
}
