// Common interfaces for safety-related components

export interface SafetySection {
  id: string;
  title: string;
  content: SafetyContent;
}

export interface SafetyContent {
  introduction?: string;
  keyPoints?: string[];
  procedures?: string[];
  warnings?: string[];
  supplies?: string[];
  symptoms?: string[];
  maintenance?: string[];
  preparations?: string[];
}

export interface SafetyChecklistItem {
  id: string;
  text: string;
  category: string;
  completed: boolean;
}

export interface PPEItem {
  id: string;
  name: string;
  description: string;
  usageGuidelines: string[];
  maintenanceSteps: string[];
  replacementIndicators: string[];
}

export interface ComplianceItem {
  id: string;
  category: string;
  items: {
    id: string;
    description: string;
    required: boolean;
    frequency: string;
  }[];
}

export interface EmergencyContact {
  name: string;
  role: string;
  phone: string;
  available: string;
}

export interface EmergencyProtocol {
  id: string;
  title: string;
  type: 'medical' | 'fire' | 'chemical' | 'equipment';
  steps: string[];
}