// Market component types
export interface Review {
  id: number;
  user: string;
  rating: number;
  comment: string;
  date: string;
}

export interface Product {
  id: number;
  name: {
    en: string;
    hi: string;
  };
  price: string;
  originalPrice?: string;
  rating: number;
  reviews: Review[];
  image: string;
  category: {
    en: string;
    hi: string;
  };
  description: {
    en: string;
    hi: string;
  };
  specifications: {
    [key: string]: string | undefined;
  };
}

export interface InteractiveRatingProps {
  rating: number;
  onRatingChange?: (rating: number) => void;
  readOnly?: boolean;
  size?: 'small' | 'medium' | 'large';
}

export interface ReviewSectionProps {
  reviews: Review[];
  productId: number;
}

export interface CartItem extends Product {
  quantity: number;
}

// Soil Analysis component types
export interface WeatherData {
  temperature: number;
  condition: string;
  humidity: number;
  windSpeed: number;
  description: string;
}

export interface CropInfo {
  en: string;
  hi: string;
}

export interface LandSizeData {
  size: CropInfo;
  recommendedCrops: CropInfo;
  rotationSuggestions: CropInfo;
  mixedCropping: CropInfo;
  benefits: CropInfo;
}

export interface SoilInfo {
  pH: number;
  Moisture: string;
  Nutrients: {
    Nitrogen: string;
    Phosphorus: string;
    Potassium: string;
  };
  Recommendations: {
    Crops: string[];
    Fertilizers: Array<{
      name: string;
      amount: string;
    }>;
    Irrigation: string;
  };
}