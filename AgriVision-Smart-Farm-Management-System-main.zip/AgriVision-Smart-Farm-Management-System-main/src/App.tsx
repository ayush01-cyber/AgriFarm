
import { useState, useEffect } from 'react'
import './App.css'
import Dashboard from './pages/Dashboard'
import Market from './pages/Marketplace'
import SoilAnalysis from './pages/Soil Analysis'
import Finance from './pages/Finance'
import Plants from './pages/Plants'
import Health from './pages/Health'
import Marketplace from './pages/Marketplace'
import AboutContact from './pages/AboutUs'

function App() {
  // Initialize activeTab from localStorage or default to 'dashboard'
  const [activeTab, setActiveTab] = useState(() => {
    const savedTab = localStorage.getItem('activeTab');
    return savedTab || 'dashboard';
  });
  const [isSidebarOpen, setSidebarOpen] = useState(() => {
    const savedState = localStorage.getItem('sidebarState');
    if (savedState !== null) {
      return JSON.parse(savedState);
    }
    return window.innerWidth > 768;
  });

  // Save activeTab to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('activeTab', activeTab);
  }, [activeTab]);

  // Update localStorage when sidebar state changes
  useEffect(() => {
    localStorage.setItem('sidebarState', JSON.stringify(isSidebarOpen));
  }, [isSidebarOpen]);

  // Handle window resize
  useEffect(() => {
    const handleResize = () => {
      setSidebarOpen(window.innerWidth > 768);
    };

    window.addEventListener('resize', handleResize);
    handleResize();

    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: '📊' },
    { id: 'market', label: 'Market & Inventory', icon: '💰' },
    { id: 'marketplace', label: 'Marketplace', icon: '🛒' },
    { id: 'soil-analysis', label: 'Soil Analysis', icon: '🌱' },
    { id: 'finance', label: 'Finance', icon: '📑' },
    { id: 'plants', label: 'Crop Information', icon: '🌿' },
    { id: 'health', label: 'Health & Safety', icon: '⚕️' },
    { id: 'about-contact', label: 'About & Contact', icon: '📞' }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      {/* Overlay for mobile sidebar */}
      {isSidebarOpen && (
        <div
          className="md:hidden fixed inset-0 bg-black/20 backdrop-blur-sm z-40"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar Toggle Button (Mobile) */}
      <button
        onClick={() => setSidebarOpen(!isSidebarOpen)}
        className="md:hidden fixed top-4 left-4 z-50 p-2 rounded-lg bg-green-600 text-white shadow-lg"
      >
        {isSidebarOpen ? '✕' : '☰'}
      </button>

      {/* Sidebar */}
      <aside className={`fixed top-0 left-0 h-screen bg-white/80 backdrop-blur-xl shadow-[0_8px_30px_rgb(0,0,0,0.04)] border-r border-gray-200/50 transition-all duration-300 ease-in-out z-50 ${isSidebarOpen ? 'w-64' : 'w-0 md:w-16'} ${isSidebarOpen ? '' : '-translate-x-full md:translate-x-0'} overflow-hidden`}>
        <div className={`p-6 bg-gradient-to-r from-green-600/40 to-green-700/40 ${!isSidebarOpen && 'md:p-4'}`}>
          <h1 className={`text-2xl font-bold text-green-800 whitespace-nowrap ${!isSidebarOpen && 'md:text-xl md:text-center'}`}>
            {isSidebarOpen ? 'AgriVision' : 'AV'}
          </h1>
          <p className={`text-green-800/80 text-sm font-medium ${!isSidebarOpen && 'md:hidden'}`}>
            Smart Farm Management
          </p>
        </div>
        <nav className="p-4">
          <ul className="space-y-2">
            {menuItems.map((item) => (
              <li key={item.id}>
                <button
                  onClick={() => {
                    setActiveTab(item.id);
                    if (window.innerWidth < 768) setSidebarOpen(false);
                  }}
                  className={`w-full flex items-center text-left px-4 py-3 rounded-xl ${activeTab === item.id ? 'bg-green-600/20 text-green-800' : 'bg-white text-gray-500'} ${!isSidebarOpen && 'md:justify-center'}`}
                  title={!isSidebarOpen ? item.label : ''}
                >
                  <span className="text-lg">{item.icon}</span>
                  <span className={`ml-3 font-medium whitespace-nowrap ${!isSidebarOpen && 'md:hidden'}`}>
                    {item.label}
                  </span>
                </button>
              </li>
            ))}
          </ul>
        </nav>
      </aside>

      {/* Main Content */}
      <main className={`min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 transition-all duration-300 ${isSidebarOpen ? 'md:ml-64' : 'md:ml-16'}`}>
        <header className="bg-white/80 backdrop-blur-xl border-b border-gray-200/50 sticky top-0 z-10">
          <div className="max-w-7xl mx-auto py-2 px-0 md:py-4 md:px-8">
            <h2 className="text-2xl font-semibold text-gray-800 flex items-center">
              <span className="text-2xl">{menuItems.find(item => item.id === activeTab)?.icon}</span>
              <span className="ml-2">{menuItems.find(item => item.id === activeTab)?.label}</span>
            </h2>
          </div>
        </header>

        <div className="max-w-7xl mx-auto py-4 px-0 md:py-8 md:px-8">
          {activeTab === 'dashboard' && <Dashboard />}
          {activeTab === 'market' && <Market />}
          {activeTab === 'marketplace' && <Marketplace />}
          {activeTab === 'soil-analysis' && <SoilAnalysis />}
          {activeTab === 'finance' && <Finance />}
          {activeTab === 'plants' && <Plants />}
          {activeTab === 'health' && <Health />}
          {activeTab === 'about-contact' && <AboutContact />}
        </div>
      </main>
    </div>
  )
}

export default App
