import React, { useState } from 'react';
import { motion } from 'framer-motion';

import { SafetySection } from '../../types/safety';

const EquipmentSafetyGuide: React.FC = () => {
  const [activeSection, setActiveSection] = useState<string>('pre-operation');

  const safetyContent: SafetySection[] = [
    {
      id: 'pre-operation',
      title: 'Pre-Operation Safety Checks',
      content: {
        introduction: 'Before operating any agricultural equipment, perform these essential safety checks to ensure safe operation and prevent accidents.',
        keyPoints: [
          'Ensure you are properly trained and authorized to operate the equipment',
          'Review the operator\'s manual and equipment-specific safety guidelines',
          'Wear appropriate Personal Protective Equipment (PPE)',
          'Check weather conditions and field visibility'
        ],
        procedures: [
          'Inspect ROPS (Rollover Protective Structure) and seatbelt condition',
          'Check all fluid levels (fuel, oil, coolant, hydraulic fluid)',
          'Verify tire condition and pressure',
          'Test all lights, flashers, and slow-moving vehicle signs',
          'Ensure all guards and shields are properly installed',
          'Check for loose, damaged, or missing parts',
          'Clear the area of bystanders, especially children'
        ],
        warnings: [
          'Never operate equipment if safety features are compromised',
          'Don\'t wear loose clothing that could get caught in moving parts',
          'Avoid operating equipment when fatigued or under the influence'
        ]
      }
    },
    {
      id: 'operation',
      title: 'Safe Operation Procedures',
      content: {
        introduction: 'Following proper operating procedures is crucial for preventing accidents and ensuring efficient farm operations.',
        keyPoints: [
          'Maintain awareness of surroundings at all times',
          'Follow recommended speed limits and operating guidelines',
          'Stay alert for obstacles, terrain changes, and hazards',
          'Keep all shields and guards in place during operation'
        ],
        procedures: [
          'Start equipment only from the operator\'s seat with transmission in neutral',
          'Keep bystanders away from operating equipment',
          'Maintain three points of contact when mounting/dismounting',
          'Watch for overhead power lines and obstacles',
          'Use extra caution on slopes and uneven terrain',
          'Never allow extra riders unless equipment is designed for it',
          'Take regular breaks to prevent fatigue'
        ],
        warnings: [
          'Never attempt to clear jams while equipment is running',
          'Avoid sudden starts, stops, or turns',
          'Don\'t operate equipment in unsafe weather conditions',
          'Never bypass or disable safety switches'
        ]
      }
    },
    {
      id: 'pto-safety',
      title: 'Power Take-Off (PTO) Safety',
      content: {
        introduction: 'PTO accidents can cause severe injury or death. Understanding and following PTO safety is essential for all equipment operators.',
        keyPoints: [
          'Always keep PTO shields in place and in good condition',
          'Never step over a rotating PTO shaft',
          'Keep clothing, hair, and body parts away from moving parts',
          'Ensure proper PTO speed matching between tractor and implement'
        ],
        procedures: [
          'Disengage PTO and shut off engine before servicing',
          'Verify all guards and shields are properly installed',
          'Check PTO shield bearings for proper rotation',
          'Ensure implement driveline is properly secured',
          'Walk around equipment, never step over PTO shaft'
        ],
        warnings: [
          'Never work around PTO with loose clothing or untucked shirts',
          'Keep children away from PTO-driven equipment',
          'Don\'t operate equipment with damaged or missing shields'
        ]
      }
    },
    {
      id: 'maintenance',
      title: 'Equipment Maintenance Safety',
      content: {
        introduction: 'Regular maintenance is crucial for equipment safety and longevity. Follow these guidelines to perform maintenance safely.',
        keyPoints: [
          'Follow manufacturer\'s maintenance schedule',
          'Use proper tools and equipment for maintenance tasks',
          'Keep maintenance records for all equipment',
          'Only perform maintenance you are qualified to do'
        ],
        procedures: [
          'Park on level ground and set parking brake',
          'Lower all implements to the ground',
          'Turn off engine and remove key',
          'Wait for all moving parts to stop',
          'Release hydraulic pressure before disconnecting lines',
          'Use proper blocking when working under equipment',
          'Replace worn or damaged parts with OEM components'
        ],
        maintenance: [
          'Check fluid levels and quality daily',
          'Inspect belts and chains for proper tension',
          'Grease all fittings according to schedule',
          'Check tire pressure and condition',
          'Inspect hydraulic hoses for wear or damage',
          'Test all safety systems and switches'
        ],
        warnings: [
          'Never work under raised equipment without proper supports',
          'Don\'t perform maintenance while equipment is running',
          'Avoid hot surfaces and pressurized systems'
        ]
      }
    }
  ];

  return (
    <div className="max-w-4xl mx-auto p-2 sm:p-6">
      <div className="mb-4 sm:mb-8 text-left">
        <h1 className="text-2xl sm:text-3xl font-bold text-green-800">Safe Agricultural Equipment Operation</h1>
        <p className="text-sm sm:text-base text-gray-600 mt-2">Comprehensive guide for safe operation and maintenance of farm equipment</p>
      </div>

      <div className="flex flex-wrap gap-2 sm:gap-4 mb-4 sm:mb-6">
        {safetyContent.map((section) => (
          <button
            key={section.id}
            onClick={() => setActiveSection(section.id)}
            className={`px-3 sm:px-4 py-1.5 sm:py-2 rounded-lg transition-colors text-left text-sm sm:text-base flex-1 sm:flex-none ${
              activeSection === section.id
                ? 'bg-green-600 text-white'
                : 'bg-white text-gray-700 hover:bg-green-50'
            }`}
          >
            {section.title}
          </button>
        ))}
      </div>

      {safetyContent.map((section) => (
        activeSection === section.id && (
          <motion.div
            key={section.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-lg shadow-lg p-6"
          >
            <h2 className="text-2xl font-bold text-green-700 mb-4">{section.title}</h2>
            
            {section.content.introduction && (
              <p className="text-gray-600 mb-6">{section.content.introduction}</p>
            )}

            {section.content.keyPoints && (
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-3">Key Points</h3>
                <ul className="list-disc list-inside space-y-2">
                  {section.content.keyPoints.map((point, index) => (
                    <li key={index} className="text-gray-600">{point}</li>
                  ))}
                </ul>
              </div>
            )}

            {section.content.procedures && (
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-3">Procedures</h3>
                <ol className="list-decimal list-inside space-y-2">
                  {section.content.procedures.map((procedure, index) => (
                    <li key={index} className="text-gray-600">{procedure}</li>
                  ))}
                </ol>
              </div>
            )}

            {section.content.maintenance && (
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-3">Maintenance Checklist</h3>
                <ul className="list-disc list-inside space-y-2">
                  {section.content.maintenance.map((item, index) => (
                    <li key={index} className="text-gray-600">{item}</li>
                  ))}
                </ul>
              </div>
            )}

            {section.content.warnings && (
              <div className="bg-red-50 border-l-4 border-red-400 p-4 rounded">
                <h3 className="text-lg font-semibold text-red-700 mb-3">⚠️ Important Warnings</h3>
                <ul className="list-disc list-inside space-y-2">
                  {section.content.warnings.map((warning, index) => (
                    <li key={index} className="text-red-600">{warning}</li>
                  ))}
                </ul>
              </div>
            )}
          </motion.div>
        )
      ))}
    </div>
  );
};

export default EquipmentSafetyGuide;
