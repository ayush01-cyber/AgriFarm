import React, { useState } from 'react';
import { motion } from 'framer-motion';

import { SafetySection } from '../../types/safety';

const FirstAidGuide: React.FC = () => {
  const [activeSection, setActiveSection] = useState<string>('basics');

  const safetyContent: SafetySection[] = [
    {
      id: 'basics',
      title: 'First Aid Basics',
      content: {
        introduction: 'Understanding basic first aid principles is essential for responding to farm emergencies effectively.',
        keyPoints: [
          'Ensure scene safety before providing aid',
          'Use appropriate personal protective equipment',
          'Call for emergency medical services when needed',
          'Stay calm and reassure the victim'
        ],
        supplies: [
          'First aid manual',
          'Sterile bandages of various sizes',
          'Adhesive tape',
          'Scissors and tweezers',
          'Antiseptic wipes',
          'Disposable gloves',
          'Emergency blanket',
          'Flashlight with extra batteries'
        ],
        warnings: [
          'Never move a seriously injured person unless in immediate danger',
          'Don\'t perform procedures you\'re not trained for',
          'Avoid contact with blood or bodily fluids without protection'
        ]
      }
    },
    {
      id: 'injuries',
      title: 'Common Farm Injuries',
      content: {
        introduction: 'Farms present unique injury risks. Knowing how to respond to common injuries can prevent complications.',
        keyPoints: [
          'Assess injury severity quickly',
          'Control bleeding immediately',
          'Keep victim warm and comfortable',
          'Document incident details when possible'
        ],
        procedures: [
          'Stop any bleeding with direct pressure',
          'Clean wounds with clean water or saline',
          'Apply appropriate dressing and bandage',
          'Monitor vital signs',
          'Keep injured area elevated if possible',
          'Apply cold packs for sprains and strains',
          'Remove any embedded objects carefully'
        ],
        warnings: [
          'Never remove large embedded objects',
          'Don\'t apply tourniquets unless trained',
          'Avoid using bare hands on open wounds'
        ]
      }
    },
    {
      id: 'heat-exposure',
      title: 'Heat-Related Emergencies',
      content: {
        introduction: 'Heat-related illnesses can be serious. Early recognition and treatment is crucial.',
        keyPoints: [
          'Monitor workers in hot conditions',
          'Encourage regular hydration',
          'Provide adequate rest periods',
          'Know signs of heat stress'
        ],
        symptoms: [
          'Heavy sweating or hot, dry skin',
          'Headache and dizziness',
          'Muscle cramps',
          'Nausea or vomiting',
          'Confusion or disorientation',
          'Rapid pulse',
          'High body temperature'
        ],
        procedures: [
          'Move person to cool area',
          'Remove excess clothing',
          'Apply cool, wet cloths',
          'Provide water if conscious',
          'Fan the person',
          'Monitor vital signs',
          'Seek medical attention if severe'
        ],
        warnings: [
          'Never ignore signs of heat exhaustion',
          'Don\'t give fluids to unconscious persons',
          'Avoid rapid cooling methods'
        ]
      }
    },
    {
      id: 'chemical-exposure',
      title: 'Chemical Exposure',
      content: {
        introduction: 'Chemical exposure requires immediate and appropriate response to minimize injury.',
        keyPoints: [
          'Know locations of emergency equipment',
          'Keep Safety Data Sheets accessible',
          'Use appropriate PPE when helping others',
          'Contact poison control if needed'
        ],
        procedures: [
          'Remove contaminated clothing safely',
          'Flush skin with clean water for 15 minutes',
          'Use eyewash station for eye exposure',
          'Identify the chemical if possible',
          'Collect product container for medical team',
          'Call emergency services',
          'Document exposure details'
        ],
        warnings: [
          'Never induce vomiting without medical advice',
          'Don\'t use neutralizing agents without guidance',
          'Avoid becoming exposed yourself while helping'
        ]
      }
    },
    {
      id: 'cpr',
      title: 'CPR and Resuscitation',
      content: {
        introduction: 'Basic life support skills can save lives in cardiac or respiratory emergencies.',
        keyPoints: [
          'Check scene safety first',
          'Verify consciousness and breathing',
          'Call emergency services immediately',
          'Begin CPR if needed'
        ],
        procedures: [
          'Check for responsiveness',
          'Call for help or send someone',
          'Check breathing for 10 seconds',
          'Begin chest compressions if needed',
          'Give rescue breaths if trained',
          'Continue until help arrives',
          'Use AED if available'
        ],
        warnings: [
          'Don\'t perform CPR without proper training',
          'Never delay starting compressions',
          'Stop if the scene becomes unsafe'
        ]
      }
    }
  ];

  return (
    <div className="max-w-4xl mx-auto p-2 sm:p-6">
      <div className="mb-4 sm:mb-8 text-left">
        <h1 className="text-2xl sm:text-3xl font-bold text-green-800">First Aid Training Guide</h1>
        <p className="text-sm sm:text-base text-gray-600 mt-2">Comprehensive guide for handling medical emergencies on the farm</p>
      </div>

      <div className="flex flex-wrap gap-2 sm:gap-4 mb-4 sm:mb-6">
        {safetyContent.map((section) => (
          <button
            key={section.id}
            onClick={() => setActiveSection(section.id)}
            className={`px-3 sm:px-4 py-1.5 sm:py-2 rounded-lg transition-colors text-left text-sm sm:text-base flex-1 sm:flex-none ${
              activeSection === section.id
                ? 'bg-green-600 text-white'
                : 'bg-white text-gray-700 hover:bg-green-50'
            }`}
          >
            {section.title}
          </button>
        ))}
      </div>

      {safetyContent.map((section) => (
        activeSection === section.id && (
          <motion.div
            key={section.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-lg shadow-lg p-6"
          >
            <h2 className="text-2xl font-bold text-green-700 mb-4">{section.title}</h2>
            
            {section.content.introduction && (
              <p className="text-gray-600 mb-6">{section.content.introduction}</p>
            )}

            {section.content.keyPoints && (
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-3">Key Points</h3>
                <ul className="list-disc list-inside space-y-2">
                  {section.content.keyPoints.map((point, index) => (
                    <li key={index} className="text-gray-600">{point}</li>
                  ))}
                </ul>
              </div>
            )}

            {section.content.supplies && (
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-3">Essential Supplies</h3>
                <ul className="list-disc list-inside space-y-2">
                  {section.content.supplies.map((item, index) => (
                    <li key={index} className="text-gray-600">{item}</li>
                  ))}
                </ul>
              </div>
            )}

            {section.content.symptoms && (
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-3">Warning Signs & Symptoms</h3>
                <ul className="list-disc list-inside space-y-2">
                  {section.content.symptoms.map((symptom, index) => (
                    <li key={index} className="text-gray-600">{symptom}</li>
                  ))}
                </ul>
              </div>
            )}

            {section.content.procedures && (
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-3">Procedures</h3>
                <ol className="list-decimal list-inside space-y-2">
                  {section.content.procedures.map((procedure, index) => (
                    <li key={index} className="text-gray-600">{procedure}</li>
                  ))}
                </ol>
              </div>
            )}

            {section.content.warnings && (
              <div className="bg-red-50 border-l-4 border-red-400 p-4 rounded">
                <h3 className="text-lg font-semibold text-red-700 mb-3">⚠️ Important Warnings</h3>
                <ul className="list-disc list-inside space-y-2">
                  {section.content.warnings.map((warning, index) => (
                    <li key={index} className="text-red-600">{warning}</li>
                  ))}
                </ul>
              </div>
            )}
          </motion.div>
        )
      ))}
    </div>
  );
};

export default FirstAidGuide;
