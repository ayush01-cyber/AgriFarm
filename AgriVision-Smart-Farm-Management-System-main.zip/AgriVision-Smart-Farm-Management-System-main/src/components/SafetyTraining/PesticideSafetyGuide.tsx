import React, { useState } from 'react';
import { motion } from 'framer-motion';

interface SafetySection {
  id: string;
  title: string;
  content: {
    introduction?: string;
    keyPoints?: string[];
    procedures?: string[];
    warnings?: string[];
    equipment?: string[];
  };
}

const PesticideSafetyGuide: React.FC = () => {
  const [activeSection, setActiveSection] = useState<string>('ppe');

  const safetyContent: SafetySection[] = [
    {
      id: 'ppe',
      title: 'Personal Protective Equipment',
      content: {
        introduction: 'Proper PPE is essential for protecting yourself from pesticide exposure. Always wear appropriate protective gear before handling any pesticides.',
        keyPoints: [
          'Inspect all PPE before use',
          'Replace damaged or worn equipment immediately',
          'Clean and maintain PPE regularly',
          'Store PPE separately from pesticides'
        ],
        equipment: [
          'Chemical-resistant gloves',
          'Protective eyewear or face shield',
          'Chemical-resistant boots',
          'Long-sleeved shirt and long pants',
          'Chemical-resistant apron',
          'Respiratory protection appropriate for the chemical',
          'Head covering'
        ],
        warnings: [
          'Never handle pesticides without proper PPE',
          'Don\'t reuse disposable PPE items',
          'Replace respirator cartridges according to schedule'
        ]
      }
    },
    {
      id: 'handling',
      title: 'Safe Handling Procedures',
      content: {
        introduction: 'Following proper handling procedures prevents accidents and ensures effective pest control.',
        keyPoints: [
          'Read and follow label instructions strictly',
          'Check weather conditions before application',
          'Maintain application equipment properly',
          'Keep detailed records of all applications'
        ],
        procedures: [
          'Mix chemicals in well-ventilated areas',
          'Use clean, calibrated measuring tools',
          'Mix only the amount needed for immediate use',
          'Triple rinse empty containers',
          'Follow proper dilution rates',
          'Maintain recommended application pressure',
          'Check for equipment leaks before starting'
        ],
        warnings: [
          'Never mix different pesticides unless specified',
          'Don\'t eat, drink, or smoke while handling pesticides',
          'Avoid working alone with highly toxic materials'
        ]
      }
    },
    {
      id: 'storage',
      title: 'Storage and Disposal',
      content: {
        introduction: 'Proper storage and disposal of pesticides is crucial for safety and environmental protection.',
        keyPoints: [
          'Maintain a dedicated, secure storage area',
          'Keep pesticides in original containers',
          'Organize products by type and hazard level',
          'Maintain updated inventory records'
        ],
        procedures: [
          'Store pesticides in a locked, well-ventilated facility',
          'Keep storage area dry and temperature-controlled',
          'Place warning signs on storage facilities',
          'Store products off the ground on pallets',
          'Maintain spill control materials',
          'Dispose of containers through authorized facilities',
          'Keep emergency numbers posted'
        ],
        warnings: [
          'Never store pesticides near food or feed',
          'Don\'t transfer pesticides to unmarked containers',
          'Avoid storing incompatible materials together'
        ]
      }
    },
    {
      id: 'emergency',
      title: 'Emergency Response',
      content: {
        introduction: 'Quick and appropriate response to pesticide emergencies can prevent serious injury or environmental damage.',
        keyPoints: [
          'Keep emergency contact numbers readily available',
          'Maintain spill control equipment',
          'Know symptoms of pesticide exposure',
          'Have SDS (Safety Data Sheets) accessible'
        ],
        procedures: [
          'Remove contaminated clothing immediately',
          'Wash affected areas with clean water',
          'Contact emergency services if needed',
          'Control and contain spills promptly',
          'Document incident details',
          'Seek medical attention for exposure',
          'Report significant spills to authorities'
        ],
        warnings: [
          'Never enter contaminated areas without protection',
          'Don\'t delay medical attention for serious exposure',
          'Avoid using water on some chemical fires'
        ]
      }
    }
  ];

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="mb-8 text-left">
        <h1 className="text-3xl font-bold text-green-800">Pesticide Safety Training Guide</h1>
        <p className="text-gray-600 mt-2">Comprehensive guide for safe handling, storage, and application of pesticides</p>
      </div>

      <div className="flex flex-wrap gap-4 mb-6">
        {safetyContent.map((section) => (
          <button
            key={section.id}
            onClick={() => setActiveSection(section.id)}
            className={`px-4 py-2 rounded-lg transition-colors ${
              activeSection === section.id
                ? 'bg-green-600 text-white'
                : 'bg-white text-gray-700 hover:bg-green-50'
            }`}
          >
            {section.title}
          </button>
        ))}
      </div>

      {safetyContent.map((section) => (
        activeSection === section.id && (
          <motion.div
            key={section.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-lg shadow-lg p-6"
          >
            <h2 className="text-2xl font-bold text-green-700 mb-4">{section.title}</h2>
            
            {section.content.introduction && (
              <p className="text-gray-600 mb-6">{section.content.introduction}</p>
            )}

            {section.content.keyPoints && (
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-3">Key Points</h3>
                <ul className="list-disc list-inside space-y-2">
                  {section.content.keyPoints.map((point, index) => (
                    <li key={index} className="text-gray-600">{point}</li>
                  ))}
                </ul>
              </div>
            )}

            {section.content.equipment && (
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-3">Required Equipment</h3>
                <ul className="list-disc list-inside space-y-2">
                  {section.content.equipment.map((item, index) => (
                    <li key={index} className="text-gray-600">{item}</li>
                  ))}
                </ul>
              </div>
            )}

            {section.content.procedures && (
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-3">Procedures</h3>
                <ol className="list-decimal list-inside space-y-2">
                  {section.content.procedures.map((procedure, index) => (
                    <li key={index} className="text-gray-600">{procedure}</li>
                  ))}
                </ol>
              </div>
            )}

            {section.content.warnings && (
              <div className="bg-red-50 border-l-4 border-red-400 p-4 rounded">
                <h3 className="text-lg font-semibold text-red-700 mb-3">⚠️ Important Warnings</h3>
                <ul className="list-disc list-inside space-y-2">
                  {section.content.warnings.map((warning, index) => (
                    <li key={index} className="text-red-600">{warning}</li>
                  ))}
                </ul>
              </div>
            )}
          </motion.div>
        )
      ))}
    </div>
  );
};

export default PesticideSafetyGuide;
