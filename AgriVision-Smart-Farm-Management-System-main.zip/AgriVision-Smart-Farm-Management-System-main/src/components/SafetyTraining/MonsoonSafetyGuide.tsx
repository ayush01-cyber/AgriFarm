import React, { useState } from 'react';
import { motion } from 'framer-motion';

import { SafetySection } from '../../types/safety';

const MonsoonSafetyGuide: React.FC = () => {
  const [activeSection, setActiveSection] = useState<string>('preparation');

  const safetyContent: SafetySection[] = [
    {
      id: 'preparation',
      title: 'Pre-Monsoon Preparation',
      content: {
        introduction: 'Proper preparation before the monsoon season is crucial for ensuring farm safety and minimizing potential damage.',
        keyPoints: [
          'Monitor weather forecasts and early warning systems',
          'Maintain emergency communication devices',
          'Keep important documents in waterproof storage',
          'Prepare emergency supply kit'
        ],
        procedures: [
          'Clear all drainage systems and channels',
          'Strengthen farm structures and repair any damages',
          'Elevate electrical equipment and connections',
          'Stock up on essential supplies and medications',
          'Create an emergency evacuation plan',
          'Mark safe routes and assembly points',
          'Service and protect farm machinery'
        ],
        warnings: [
          'Never ignore weather warnings or evacuation notices',
          'Don\'t store hazardous materials in flood-prone areas',
          'Avoid last-minute preparations during heavy rain'
        ]
      }
    },
    {
      id: 'field-operations',
      title: 'Field Operations Safety',
      content: {
        introduction: 'Monsoon conditions require special attention to field operations to ensure worker safety and protect crops.',
        keyPoints: [
          'Assess field conditions before starting work',
          'Use appropriate protective gear for wet conditions',
          'Maintain clear communication with field workers',
          'Keep first aid supplies readily available'
        ],
        procedures: [
          'Check field drainage before entering',
          'Use proper footwear with good grip',
          'Work in pairs when possible',
          'Carry communication devices at all times',
          'Take regular breaks to prevent fatigue',
          'Monitor weather changes continuously',
          'Keep equipment on stable ground'
        ],
        warnings: [
          'Never work in fields during lightning storms',
          'Avoid crossing flooded areas or streams',
          'Don\'t operate machinery on waterlogged soil'
        ]
      }
    },
    {
      id: 'crop-protection',
      title: 'Crop Protection Measures',
      content: {
        introduction: 'Protecting crops during monsoon requires specific measures to prevent damage and disease.',
        keyPoints: [
          'Monitor crop health regularly',
          'Implement disease prevention strategies',
          'Maintain proper drainage systems',
          'Keep pest control measures ready'
        ],
        procedures: [
          'Install proper drainage around crop areas',
          'Apply appropriate fungicides preventively',
          'Remove infected plants promptly',
          'Maintain proper plant spacing',
          'Support tall crops with stakes',
          'Cover sensitive crops when necessary',
          'Monitor soil moisture levels'
        ],
        warnings: [
          'Don\'t apply chemicals during heavy rain',
          'Avoid excessive irrigation in wet conditions',
          'Never mix incompatible pesticides'
        ]
      }
    },
    {
      id: 'emergency-response',
      title: 'Emergency Response',
      content: {
        introduction: 'Being prepared for monsoon emergencies can prevent loss of life and minimize damage to farm assets.',
        keyPoints: [
          'Keep emergency contacts readily available',
          'Know evacuation routes and safe zones',
          'Maintain emergency equipment in working order',
          'Train workers in emergency procedures'
        ],
        procedures: [
          'Move to higher ground during floods',
          'Shut off electrical equipment safely',
          'Secure loose items and equipment',
          'Account for all personnel',
          'Follow evacuation protocols',
          'Document damage for insurance',
          'Contact emergency services when needed'
        ],
        warnings: [
          'Never attempt to drive through floodwater',
          'Don\'t return to flooded areas until cleared',
          'Avoid contact with flood-contaminated water'
        ]
      }
    }
  ];

  return (
    <div className="max-w-4xl mx-auto p-2 sm:p-6 text-left">
      <div className="mb-4 sm:mb-8">
        <h1 className="text-2xl sm:text-3xl font-bold text-green-800">Monsoon Season Safety Guide</h1>
        <p className="text-sm sm:text-base text-gray-600 mt-2">Comprehensive guide for managing farm safety during monsoon season</p>
      </div>

      <div className="flex flex-wrap gap-2 sm:gap-4 mb-4 sm:mb-6">
        {safetyContent.map((section) => (
          <button
            key={section.id}
            onClick={() => setActiveSection(section.id)}
            className={`px-3 sm:px-4 py-1.5 sm:py-2 rounded-lg transition-colors text-left text-sm sm:text-base flex-1 sm:flex-none ${
              activeSection === section.id
                ? 'bg-green-600 text-white'
                : 'bg-white text-gray-700 hover:bg-green-50'
            }`}
          >
            {section.title}
          </button>
        ))}
      </div>

      {safetyContent.map((section) => (
        activeSection === section.id && (
          <motion.div
            key={section.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-lg shadow-lg p-6"
          >
            <h2 className="text-2xl font-bold text-green-700 mb-4">{section.title}</h2>
            
            {section.content.introduction && (
              <p className="text-gray-600 mb-6">{section.content.introduction}</p>
            )}

            {section.content.keyPoints && (
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-3">Key Points</h3>
                <ul className="list-disc list-inside space-y-2">
                  {section.content.keyPoints.map((point, index) => (
                    <li key={index} className="text-gray-600">{point}</li>
                  ))}
                </ul>
              </div>
            )}

            {section.content.procedures && (
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-3">Procedures</h3>
                <ol className="list-decimal list-inside space-y-2">
                  {section.content.procedures.map((procedure, index) => (
                    <li key={index} className="text-gray-600">{procedure}</li>
                  ))}
                </ol>
              </div>
            )}

            {section.content.warnings && (
              <div className="bg-red-50 border-l-4 border-red-400 p-4 rounded">
                <h3 className="text-lg font-semibold text-red-700 mb-3">⚠️ Important Warnings</h3>
                <ul className="list-disc list-inside space-y-2">
                  {section.content.warnings.map((warning, index) => (
                    <li key={index} className="text-red-600">{warning}</li>
                  ))}
                </ul>
              </div>
            )}
          </motion.div>
        )
      ))}
    </div>
  );
};

export default MonsoonSafetyGuide;
