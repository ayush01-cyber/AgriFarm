import React, { useState } from 'react';
import { motion } from 'framer-motion';
import EquipmentSafetyGuide from './EquipmentSafetyGuide';
import MonsoonSafetyGuide from './MonsoonSafetyGuide';
import PesticideSafetyGuide from './PesticideSafetyGuide';
import FirstAidGuide from './FirstAidGuide';

interface TrainingModule {
  id: string;
  title: string;
  description: string;
  duration: string;
  language: string;
  type: 'document' | 'interactive';
  url: string;
}

const SafetyTrainingPortal: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedModule, setSelectedModule] = useState<string | null>(null);

  const trainingModules: TrainingModule[] = [
    {
      id: '1',
      title: 'Safe Agricultural Equipment Operation',
      description: 'Comprehensive guide for safe operation of farming equipment',
      duration: '30 minutes',
      language: 'English',
      type: 'document',
      url: '#equipment-safety'
    },
    {
      id: '2',
      title: 'Monsoon Season Safety',
      description: 'Detailed guide on safety measures during monsoon farming',
      duration: '45 minutes',
      language: 'English',
      type: 'document',
      url: '#monsoon-safety'
    },
    {
      id: '3',
      title: 'Pesticide Safety Training',
      description: 'Safe handling and storage of pesticides',
      duration: '1 hour',
      language: 'English',
      type: 'document',
      url: '#pesticide-safety'
    },
    {
      id: '4',
      title: 'First Aid Training',
      description: 'Essential first aid procedures for farm emergencies',
      duration: '2 hours',
      language: 'English',
      type: 'document',
      url: '#first-aid'
    }
  ];

  const filteredModules = trainingModules.filter(module => {
    const matchesSearch = module.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         module.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || module.type === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const renderSelectedModule = () => {
    switch (selectedModule) {
      case '1':
        return <EquipmentSafetyGuide />;
      case '2':
        return <MonsoonSafetyGuide />;
      case '3':
        return <PesticideSafetyGuide />;
      case '4':
        return <FirstAidGuide />;
      default:
        return null;
    }
  };

  if (selectedModule) {
    return (
      <div>
        <button
          onClick={() => setSelectedModule(null)}
          className="mb-6 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
        >
          ← Back to Training Modules
        </button>
        {renderSelectedModule()}
      </div>
    );
  }

  return (
    <div className="p-0 sm:p-6 max-w-7xl mx-auto">
      <div className="mb-2 sm:mb-8 text-left px-2 sm:px-0">
        <h1 className="text-2xl sm:text-3xl font-bold text-green-800 mb-2 text-left">Safety Training Portal</h1>
        <p className="text-sm sm:text-base text-gray-600 text-left">Your safety is our priority. Learn safe farming practices with our training modules.</p>
      </div>

      <div className="flex flex-col gap-1 sm:gap-4 mb-2 sm:mb-6 px-2 sm:px-0">
        <input
          type="text"
          placeholder="Search training..."
          className="w-full p-2 border rounded-lg text-left text-sm sm:text-base"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
        <select
          className="w-full p-2 border rounded-lg bg-white text-left text-sm sm:text-base"
          value={selectedCategory}
          onChange={(e) => setSelectedCategory(e.target.value)}
        >
          <option value="all">All Types</option>
          <option value="document">Document</option>
          <option value="interactive">Interactive</option>
        </select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-4 sm:gap-6 px-2 sm:px-0">
        {filteredModules.map((module) => (
          <motion.div
            key={module.id}
            whileHover={{ scale: 1.02 }}
            className="bg-white rounded-lg shadow-lg overflow-hidden border border-gray-100 hover:border-green-200 transition-colors"
          >
            <div className="p-4 sm:p-6 h-full flex flex-col justify-between text-left">
              <div>
                <div className={`text-xs sm:text-sm font-semibold mb-3 inline-block px-3 py-1.5 rounded-full text-left
                  ${module.type === 'interactive' ? 'bg-purple-100 text-purple-800' : 'bg-green-100 text-green-800'}`}>
                  {module.type.charAt(0).toUpperCase() + module.type.slice(1)}
                </div>
                <h3 className="text-xl font-semibold mb-3 text-left text-gray-800">{module.title}</h3>
                <p className="text-base text-gray-600 text-left leading-relaxed">{module.description}</p>
              </div>
              <button
                onClick={() => setSelectedModule(module.id)}
                className="w-full mt-6 bg-green-600 text-white py-3 px-6 rounded-lg hover:bg-green-700 transition-colors text-base font-medium text-center hover:shadow-md"
              >
                Start Now
              </button>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default SafetyTrainingPortal;
