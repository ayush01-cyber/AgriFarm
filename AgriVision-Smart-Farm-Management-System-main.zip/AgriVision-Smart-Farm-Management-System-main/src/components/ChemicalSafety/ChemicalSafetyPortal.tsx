import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChemicalType, StorageGuideline, ApplicationGuideline, ProtectiveMeasure } from '../../types/chemical';

// Data based on Madhya Pradesh agricultural context
const chemicalTypes: ChemicalType[] = [
  {
    id: 'insecticide',
    name: 'Insecticides',
    examples: ['Malathion', 'Chlorpyrifos', 'Cypermethrin'],
    hazardLevel: 'high',
    commonCrops: ['Soybean', 'Cotton', 'Wheat'],
    weatherConsiderations: {
      temperature: '15-30°C',
      humidity: '40-60%',
      windSpeed: '<10 km/h'
    }
  },
  {
    id: 'herbicide',
    name: 'Herbicides',
    examples: ['Glyphosate', '2,4-D', 'Pendimethalin'],
    hazardLevel: 'medium',
    commonCrops: ['Wheat', 'Rice', 'Pulses'],
    weatherConsiderations: {
      temperature: '20-35°C',
      humidity: '50-70%',
      windSpeed: '<15 km/h'
    }
  },
  {
    id: 'fungicide',
    name: 'Fungicides',
    examples: ['Carbendazim', 'Mancozeb', 'Copper Oxychloride'],
    hazardLevel: 'medium',
    commonCrops: ['Soybean', 'Chickpea', 'Vegetables'],
    weatherConsiderations: {
      temperature: '18-28°C',
      humidity: '60-80%',
      windSpeed: '<12 km/h'
    }
  }
];

const storageGuidelines: StorageGuideline[] = [
  {
    id: 'storage-location',
    title: 'Storage Location (स्टोरेज स्थान)',
    guidelines: [
      'Store in a dedicated, well-ventilated room away from residential areas',
      'Room should be cool, dry, and protected from direct sunlight',
      'Keep storage area locked and marked with warning signs in Hindi and English',
      'Maintain minimum 3 meters distance from water sources'
    ]
  },
  {
    id: 'container-management',
    title: 'Container Management (कंटेनर प्रबंधन)',
    guidelines: [
      'Keep chemicals in original containers with intact labels',
      'Store different chemical types separately',
      'Place heavy containers at the bottom',
      'Use metal or sturdy plastic shelves'
    ]
  },
  {
    id: 'emergency-preparedness',
    title: 'Emergency Preparedness (आपातकालीन तैयारी)',
    guidelines: [
      'Keep spill control materials readily available',
      'Display emergency contact numbers prominently',
      'Maintain a first-aid kit nearby',
      'Install fire extinguisher and smoke detector'
    ]
  }
];

const applicationGuidelines: ApplicationGuideline[] = [
  {
    id: 'pre-application',
    title: 'Pre-Application (उपयोग से पहले)',
    steps: [
      'Read and understand the label instructions thoroughly',
      'Check weather forecast - avoid application before rain',
      'Calibrate spraying equipment',
      'Notify nearby farmers and residents'
    ]
  },
  {
    id: 'during-application',
    title: 'During Application (उपयोग के दौरान)',
    steps: [
      'Wear appropriate PPE as per chemical type',
      'Apply in early morning or late evening',
      'Follow wind direction while spraying',
      'Maintain recommended dilution rates'
    ]
  },
  {
    id: 'post-application',
    title: 'Post-Application (उपयोग के बाद)',
    steps: [
      'Clean equipment thoroughly',
      'Dispose of empty containers properly',
      'Mark treated areas with warning signs',
      'Record application details in register'
    ]
  }
];

const protectiveMeasures: Record<string, ProtectiveMeasure[]> = {
  insecticide: [
    { item: 'Chemical Resistant Suit', required: true },
    { item: 'Full Face Respirator', required: true },
    { item: 'Chemical Resistant Gloves', required: true },
    { item: 'Rubber Boots', required: true },
    { item: 'Face Shield', required: true }
  ],
  herbicide: [
    { item: 'Long-sleeved Shirt', required: true },
    { item: 'Half Face Respirator', required: true },
    { item: 'Chemical Resistant Gloves', required: true },
    { item: 'Rubber Boots', required: true },
    { item: 'Safety Goggles', required: true }
  ],
  fungicide: [
    { item: 'Long-sleeved Shirt', required: true },
    { item: 'Dust Mask', required: true },
    { item: 'Chemical Resistant Gloves', required: true },
    { item: 'Rubber Boots', required: true },
    { item: 'Safety Goggles', required: true }
  ]
};

const ChemicalSafetyPortal: React.FC = () => {
  const [activeSection, setActiveSection] = useState<string>('storage');
  const [selectedChemicalType, setSelectedChemicalType] = useState<string>('insecticide');

  const renderSafetyVideo = () => (
    <div className="space-y-8">
      <h2 className="text-2xl font-bold text-green-700 mb-6">Safety Training Video</h2>
      <div className="bg-white rounded-lg sm:p-6 sm:shadow-sm sm:border sm:border-gray-200">
        <h3 className="text-xl font-semibold text-gray-800 mb-4 text-left px-2 sm:px-0">Safety Measures for Farm Workers Handling Pesticides</h3>
        <div className="relative w-full pb-[56.25%]">
          <iframe
            src="https://www.youtube.com/embed/r9x33zkLdKA"
            title="Safety Measures for Farm Workers Handling Pesticides"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
            className="absolute top-0 left-0 w-full h-full rounded-lg"
          ></iframe>
        </div>
      </div>
    </div>
  );

  const renderStorageGuidelines = () => (
    <div className="space-y-8">
      <h2 className="text-2xl font-bold text-green-700 mb-6 text-center">Chemical Storage Guidelines</h2>
      {storageGuidelines.map((section) => (
        <div key={section.id} className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
          <h3 className="text-xl font-semibold text-gray-800 mb-4 text-left">{section.title}</h3>
          <ul className="list-disc space-y-3 pl-4">
            {section.guidelines.map((guideline, index) => (
              <li key={index} className="text-gray-600 text-left">{guideline}</li>
            ))}
          </ul>
        </div>
      ))}
    </div>
  );

  const renderApplicationGuidelines = () => (
    <div className="space-y-8">
      <h2 className="text-2xl font-bold text-green-700 mb-6 text-center">Pesticide Application Safety</h2>
      {applicationGuidelines.map((section) => (
        <div key={section.id} className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
          <h3 className="text-xl font-semibold text-gray-800 mb-4 text-left">{section.title}</h3>
          <ul className="list-disc space-y-3 pl-4">
            {section.steps.map((step, index) => (
              <li key={index} className="text-gray-600 text-left">{step}</li>
            ))}
          </ul>
        </div>
      ))}
    </div>
  );

  const renderProtectiveMeasures = () => {
    const selectedChemical = chemicalTypes.find(type => type.id === selectedChemicalType);
    const measures = protectiveMeasures[selectedChemicalType];

    return (
      <div className="space-y-8">
        <h2 className="text-2xl font-bold text-green-700 mb-6">Protective Measure Calculator</h2>
        
        <div className="mb-6">
          <div className="flex flex-wrap gap-3">
            {chemicalTypes.map(type => (
              <button
                key={type.id}
                onClick={() => setSelectedChemicalType(type.id)}
                className={`px-4 py-2 rounded-lg transition-all duration-300 transform hover:scale-105 ${
                  selectedChemicalType === type.id
                    ? 'bg-green-600 text-white shadow-lg scale-105'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {type.name}
              </button>
            ))}
          </div>
        </div>

        {selectedChemical && (
          <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <div className="mb-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-2">Chemical Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-500">Hazard Level</p>
                  <p className="text-base text-gray-900 capitalize">{selectedChemical.hazardLevel}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Common Examples</p>
                  <p className="text-base text-gray-900">{selectedChemical.examples.join(', ')}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Common Crops</p>
                  <p className="text-base text-gray-900">{selectedChemical.commonCrops.join(', ')}</p>
                </div>
              </div>
            </div>

            <div className="mb-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-2">Weather Considerations</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <p className="text-sm text-gray-500">Temperature</p>
                  <p className="text-base text-gray-900">{selectedChemical.weatherConsiderations.temperature}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Humidity</p>
                  <p className="text-base text-gray-900">{selectedChemical.weatherConsiderations.humidity}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Wind Speed</p>
                  <p className="text-base text-gray-900">{selectedChemical.weatherConsiderations.windSpeed}</p>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-800 mb-2">Required Protective Equipment</h3>
              <ul className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {measures.map((measure, index) => (
                  <li key={index} className="flex items-center space-x-3">
                    <svg className={`h-5 w-5 ${measure.required ? 'text-green-500' : 'text-gray-400'}`} fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                    </svg>
                    <span className="text-gray-700">{measure.item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="max-w-7xl mx-auto p-0 sm:p-6">
      <div className="mb-3 sm:mb-8 px-2 sm:px-0 text-left">
        <h1 className="text-2xl sm:text-3xl font-bold text-green-800 text-left">Chemical Safety Management</h1>
        <p className="text-sm sm:text-base text-gray-600 mt-2 text-left">Comprehensive guidelines for safe chemical handling in agriculture</p>
      </div>

      <div className="flex flex-wrap gap-1 sm:gap-4 mb-4 sm:mb-6 px-2 sm:px-0">
        <button
          onClick={() => setActiveSection('storage')}
          className={`px-2 sm:px-4 py-1 sm:py-2 text-sm sm:text-base rounded-lg transition-all duration-300 transform hover:scale-102 flex-1 sm:flex-none text-left ${activeSection === 'storage' ? 'bg-green-600 text-white shadow-lg scale-105' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
        >
          Storage Guidelines
        </button>
        <button
          onClick={() => setActiveSection('application')}
          className={`px-2 sm:px-4 py-1 sm:py-2 text-sm sm:text-base rounded-lg transition-all duration-300 transform hover:scale-102 flex-1 sm:flex-none text-left ${activeSection === 'application' ? 'bg-green-600 text-white shadow-lg scale-105' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
        >
          Application Safety
        </button>
        <button
          onClick={() => setActiveSection('protective')}
          className={`px-2 sm:px-4 py-1 sm:py-2 text-sm sm:text-base rounded-lg transition-all duration-300 transform hover:scale-102 flex-1 sm:flex-none text-left ${activeSection === 'protective' ? 'bg-green-600 text-white shadow-lg scale-105' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
        >
          Protective Measures
        </button>
        <button
          onClick={() => setActiveSection('video')}
          className={`px-2 sm:px-4 py-1 sm:py-2 text-sm sm:text-base rounded-lg transition-all duration-300 transform hover:scale-102 flex-1 sm:flex-none text-left ${activeSection === 'video' ? 'bg-green-600 text-white shadow-lg scale-105' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
        >
          Safety Video
        </button>
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={activeSection}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.2 }}
          className="px-2 sm:px-0"
        >
          {activeSection === 'storage' && renderStorageGuidelines()}
          {activeSection === 'application' && renderApplicationGuidelines()}
          {activeSection === 'protective' && renderProtectiveMeasures()}
          {activeSection === 'video' && renderSafetyVideo()}
        </motion.div>
      </AnimatePresence>
    </div>
  );
};

export default ChemicalSafetyPortal;
