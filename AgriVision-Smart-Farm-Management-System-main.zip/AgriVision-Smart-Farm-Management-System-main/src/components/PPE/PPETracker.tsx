import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface PPEItem {
  id: string;
  name: string;
  description: string;
  usageGuidelines: string[];
  maintenanceSteps: string[];
  replacementIndicators: string[];
  image?: string;
}

interface ComplianceItem {
  id: string;
  category: string;
  items: {
    id: string;
    description: string;
    required: boolean;
    frequency: string;
  }[];
}

const PPETracker: React.FC = () => {
  const [activeSection, setActiveSection] = useState<string>('guide');

  const ppeItems: PPEItem[] = [
    {
      id: 'safety-helmet',
      name: 'Safety Helmet',
      description: 'Protective headgear for impact protection and electrical hazards',
      usageGuidelines: [
        'Inspect before each use for cracks or damage',
        'Adjust suspension system for proper fit',
        'Replace after any significant impact',
        'Keep away from direct sunlight when not in use'
      ],
      maintenanceSteps: [
        'Clean with mild soap and warm water',
        'Check suspension system monthly',
        'Store in a cool, dry place',
        'Replace suspension every 12 months'
      ],
      replacementIndicators: [
        'Visible cracks or dents',
        'Suspension system wear',
        'After 5 years of use',
        'Following any significant impact'
      ]
    },
    {
      id: 'chemical-gloves',
      name: 'Chemical Resistant Gloves',
      description: 'Protection against chemical exposure during pesticide handling',
      usageGuidelines: [
        'Check for tears or holes before use',
        'Wear over clean, dry hands',
        'Remove carefully to avoid contamination',
        'Wash hands after removal'
      ],
      maintenanceSteps: [
        'Rinse after each use',
        'Air dry away from direct sunlight',
        'Store in clean, dry area',
        'Check for degradation regularly'
      ],
      replacementIndicators: [
        'Visible tears or holes',
        'Material becoming sticky or soft',
        'Loss of flexibility',
        'After heavy chemical exposure'
      ]
    },
    {
      id: 'respirator',
      name: 'Respiratory Protection',
      description: 'Protects against airborne particles and chemical vapors',
      usageGuidelines: [
        'Perform seal check before each use',
        'Use appropriate cartridges for the hazard',
        'Ensure proper fit testing',
        'Store in sealed container'
      ],
      maintenanceSteps: [
        'Clean after each use',
        'Replace cartridges according to schedule',
        'Check straps and valves monthly',
        'Store away from contaminants'
      ],
      replacementIndicators: [
        'Breathing difficulty',
        'Damaged valves or straps',
        'Failed seal check',
        'According to cartridge schedule'
      ]
    }
  ];

  const complianceChecklist: ComplianceItem[] = [
    {
      id: 'daily',
      category: 'Daily Inspections',
      items: [
        {
          id: 'ppe-availability',
          description: 'Verify PPE availability at designated stations',
          required: true,
          frequency: 'Daily'
        },
        {
          id: 'condition-check',
          description: 'Check condition of actively used PPE',
          required: true,
          frequency: 'Daily'
        },
        {
          id: 'cleaning-verify',
          description: 'Verify cleaning of reusable PPE',
          required: true,
          frequency: 'Daily'
        }
      ]
    },
    {
      id: 'weekly',
      category: 'Weekly Checks',
      items: [
        {
          id: 'inventory-count',
          description: 'Conduct inventory count of all PPE',
          required: true,
          frequency: 'Weekly'
        },
        {
          id: 'storage-inspection',
          description: 'Inspect PPE storage conditions',
          required: true,
          frequency: 'Weekly'
        },
        {
          id: 'expiry-check',
          description: 'Check for expired or soon-to-expire items',
          required: true,
          frequency: 'Weekly'
        }
      ]
    },
    {
      id: 'monthly',
      category: 'Monthly Assessments',
      items: [
        {
          id: 'training-review',
          description: 'Review PPE training records',
          required: true,
          frequency: 'Monthly'
        },
        {
          id: 'maintenance-check',
          description: 'Comprehensive maintenance check of all PPE',
          required: true,
          frequency: 'Monthly'
        },
        {
          id: 'compliance-audit',
          description: 'Conduct PPE compliance audit',
          required: true,
          frequency: 'Monthly'
        }
      ]
    }
  ];

  const renderContent = () => {
    switch (activeSection) {
      case 'guide':
        return (
          <div className="space-y-8">
            <h2 className="text-2xl font-bold text-green-700 mb-6">PPE Visual Guide</h2>
            {ppeItems.map((item) => (
              <div key={item.id} className="border rounded-lg p-6">
                <h3 className="text-xl font-semibold text-gray-800 mb-4">{item.name}</h3>
                <p className="text-gray-600 mb-4">{item.description}</p>
                
                <div className="grid md:grid-cols-3 gap-6">
                  <div>
                    <h4 className="font-semibold text-green-700 mb-2">Usage Guidelines</h4>
                    <ul className="list-disc list-inside space-y-2">
                      {item.usageGuidelines.map((guideline, index) => (
                        <li key={index} className="text-gray-600">{guideline}</li>
                      ))}
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold text-green-700 mb-2">Maintenance</h4>
                    <ul className="list-disc list-inside space-y-2">
                      {item.maintenanceSteps.map((step, index) => (
                        <li key={index} className="text-gray-600">{step}</li>
                      ))}
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold text-green-700 mb-2">When to Replace</h4>
                    <ul className="list-disc list-inside space-y-2">
                      {item.replacementIndicators.map((indicator, index) => (
                        <li key={index} className="text-gray-600">{indicator}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>
        );

      case 'compliance':
        return (
          <div>
            <h2 className="text-2xl font-bold text-green-700 mb-6">PPE Compliance Checklist</h2>
            {complianceChecklist.map((category) => (
              <div key={category.id} className="mb-8">
                <h3 className="text-xl font-semibold text-gray-800 mb-4">{category.category}</h3>
                <div className="bg-white rounded-lg border">
                  {category.items.map((item, index) => (
                    <div key={item.id} className={`p-4 ${index !== 0 ? 'border-t' : ''}`}>
                      <div className="flex items-start">
                        <div className="flex-shrink-0">
                          <input
                            type="checkbox"
                            className="h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded"
                          />
                        </div>
                        <div className="ml-3">
                          <p className="text-sm font-medium text-gray-700">{item.description}</p>
                          <p className="text-sm text-gray-500">
                            Frequency: {item.frequency}
                            {item.required && <span className="ml-2 text-red-500">*Required</span>}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="max-w-7xl mx-auto p-0 sm:p-6">
      <div className="mb-3 sm:mb-8 px-2 sm:px-0">
        <h1 className="text-2xl sm:text-3xl font-bold text-green-800">PPE Tracker</h1>
        <p className="text-sm sm:text-base text-gray-600 mt-2">Comprehensive PPE management and compliance system</p>
      </div>

      <div className="flex flex-wrap gap-1 sm:gap-4 mb-4 sm:mb-6 px-2 sm:px-0">
        <button
          onClick={() => setActiveSection('guide')}
          className={`px-2 sm:px-4 py-1 sm:py-2 text-sm sm:text-base rounded-lg transition-all duration-300 transform hover:scale-102 flex-1 sm:flex-none ${activeSection === 'guide' ? 'bg-green-600 text-white shadow-lg scale-105' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
        >
          Visual Guide
        </button>
        <button
          onClick={() => setActiveSection('compliance')}
          className={`px-2 sm:px-4 py-1 sm:py-2 text-sm sm:text-base rounded-lg transition-all duration-300 transform hover:scale-102 flex-1 sm:flex-none ${activeSection === 'compliance' ? 'bg-green-600 text-white shadow-lg scale-105' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
        >
          Compliance Checklist
        </button>
      </div>

      <AnimatePresence>
        <motion.div
          key={activeSection}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          className="bg-white rounded-lg shadow-lg p-4 sm:p-6 px-2 sm:px-6"
        >
          {renderContent()}
        </motion.div>
      </AnimatePresence>
    </div>
  );
};

export default PPETracker;
