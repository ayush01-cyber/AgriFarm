import React, { useState } from 'react';
import { motion } from 'framer-motion';

interface HealthMetric {
  id: string;
  title: string;
  value: number;
  unit: string;
  status: 'good' | 'warning' | 'critical';
  trend: 'up' | 'down' | 'stable';
}

interface SafetyIncident {
  id: string;
  date: string;
  type: string;
  severity: 'low' | 'medium' | 'high';
  status: 'resolved' | 'in-progress' | 'pending';
  description: string;
}

const HealthMonitoring: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'metrics' | 'incidents'>('metrics');

  const healthMetrics: HealthMetric[] = [
    {
      id: 'heat-exposure',
      title: 'Heat Exposure Index',
      value: 82,
      unit: '°F',
      status: 'warning',
      trend: 'up'
    },
    {
      id: 'air-quality',
      title: 'Air Quality Index',
      value: 45,
      unit: 'AQI',
      status: 'good',
      trend: 'stable'
    },
    {
      id: 'noise-level',
      title: 'Noise Level',
      value: 85,
      unit: 'dB',
      status: 'warning',
      trend: 'up'
    },
    {
      id: 'chemical-exposure',
      title: 'Chemical Exposure Risk',
      value: 2,
      unit: 'Level',
      status: 'good',
      trend: 'down'
    }
  ];

  const safetyIncidents: SafetyIncident[] = [
    {
      id: 'inc1',
      date: '2025-02-20',
      type: 'Equipment Malfunction',
      severity: 'medium',
      status: 'resolved',
      description: 'Tractor hydraulic system failure during field operation. No injuries reported.'
    },
    {
      id: 'inc2',
      date: '2025-02-18',
      type: 'Chemical Exposure',
      severity: 'low',
      status: 'resolved',
      description: 'Minor pesticide splash during mixing. PPE prevented injury.'
    },
    {
      id: 'inc3',
      date: '2025-02-15',
      type: 'Heat Stress',
      severity: 'high',
      status: 'in-progress',
      description: 'Worker experienced heat exhaustion symptoms. Implementing additional break protocols.'
    }
  ];

  return (
    <div className="max-w-7xl mx-auto p-0 sm:p-6">
      <div className="mb-2 sm:mb-8 text-left px-2 sm:px-0">
        <h2 className="text-2xl sm:text-3xl font-bold text-green-800 mb-2">Health & Safety Monitoring</h2>
        <p className="text-sm sm:text-base text-gray-600">Real-time monitoring of farm safety metrics and incident tracking</p>
      </div>

      <div className="flex flex-wrap gap-1 sm:gap-4 mb-2 sm:mb-6 px-2 sm:px-0">
        <button
          onClick={() => setActiveTab('metrics')}
          className={`px-3 sm:px-4 py-1.5 sm:py-2 rounded-lg transition-colors text-sm sm:text-base flex-1 sm:flex-none ${activeTab === 'metrics' ? 'bg-green-600 text-white' : 'bg-white text-gray-700 hover:bg-green-50'}`}
        >
          Safety Metrics
        </button>
        <button
          onClick={() => setActiveTab('incidents')}
          className={`px-3 sm:px-4 py-1.5 sm:py-2 rounded-lg transition-colors text-sm sm:text-base flex-1 sm:flex-none ${activeTab === 'incidents' ? 'bg-green-600 text-white' : 'bg-white text-gray-700 hover:bg-green-50'}`}
        >
          Incident Reports
        </button>
      </div>

      {activeTab === 'metrics' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 sm:gap-6 px-2 sm:px-0">
          {healthMetrics.map((metric) => (
            <motion.div
              key={metric.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-lg shadow-lg p-4 sm:p-6"
            >
              <div className="flex justify-between items-start text-left">
                <h3 className="text-base sm:text-lg font-semibold text-gray-800">{metric.title}</h3>
                <span
                  className={`px-2 py-1 rounded text-xs sm:text-sm font-semibold ${metric.status === 'good' ? 'bg-green-100 text-green-800' : metric.status === 'warning' ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800'}`}
                >
                  {metric.status.toUpperCase()}
                </span>
              </div>
              <div className="mt-3 sm:mt-4 flex items-end gap-2">
                <span className="text-2xl sm:text-3xl font-bold text-gray-900">{metric.value}</span>
                <span className="text-sm sm:text-base text-gray-600 mb-1">{metric.unit}</span>
                <span className="ml-auto text-base sm:text-lg">
                  {metric.trend === 'up' ? '↑' : metric.trend === 'down' ? '↓' : '→'}
                </span>
              </div>
            </motion.div>
          ))}
        </div>
      ) : (
        <div className="space-y-2 sm:space-y-4 px-2 sm:px-0">
          {safetyIncidents.map((incident) => (
            <motion.div
              key={incident.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-white rounded-lg shadow-lg p-4 sm:p-6"
            >
              <div className="flex flex-col sm:flex-row justify-between items-start gap-2 sm:gap-4 text-left">
                <div>
                  <h3 className="text-base sm:text-lg font-semibold text-gray-800">{incident.type}</h3>
                  <p className="text-xs sm:text-sm text-gray-500">{incident.date}</p>
                </div>
                <div className="flex gap-2 flex-wrap">
                  <span
                    className={`px-2 py-1 rounded text-xs sm:text-sm font-semibold ${incident.severity === 'low' ? 'bg-blue-100 text-blue-800' : incident.severity === 'medium' ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800'}`}
                  >
                    {incident.severity.toUpperCase()}
                  </span>
                  <span
                    className={`px-2 py-1 rounded text-xs sm:text-sm font-semibold ${incident.status === 'resolved' ? 'bg-green-100 text-green-800' : incident.status === 'in-progress' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'}`}
                  >
                    {incident.status.replace('-', ' ').toUpperCase()}
                  </span>
                </div>
              </div>
              <p className="mt-2 text-sm sm:text-base text-gray-600">{incident.description}</p>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
};

export default HealthMonitoring;
