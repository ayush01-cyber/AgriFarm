import React from 'react';
import { motion } from 'framer-motion';

interface GuidelineCategory {
  id: string;
  title: string;
  guidelines: Guideline[];
}

interface Guideline {
  id: string;
  title: string;
  description: string;
  importance: 'critical' | 'important' | 'recommended';
}

const SafetyGuidelines: React.FC = () => {
  const guidelines: GuidelineCategory[] = [
    {
      id: 'equipment',
      title: 'Equipment Safety',
      guidelines: [
        {
          id: 'eq1',
          title: 'Tractor Safety Protocol',
          description: 'Always use ROPS (Rollover Protective Structure) and seatbelt. Never allow extra riders. Ensure PTO shields are in place.',
          importance: 'critical'
        },
        {
          id: 'eq2',
          title: 'Machinery Maintenance',
          description: 'Perform regular equipment inspections. Keep guards and shields in place. Shut down and disable equipment before maintenance.',
          importance: 'critical'
        },
        {
          id: 'eq3',
          title: 'Safe Operation Practices',
          description: 'Read and follow manufacturer\'s instructions. Train all operators. Keep children away from equipment.',
          importance: 'important'
        }
      ]
    },
    {
      id: 'chemical',
      title: 'Chemical Safety',
      guidelines: [
        {
          id: 'ch1',
          title: 'Pesticide Handling',
          description: 'Use appropriate PPE. Follow label instructions strictly. Store chemicals in original containers in locked storage.',
          importance: 'critical'
        },
        {
          id: 'ch2',
          title: 'Application Safety',
          description: 'Check weather conditions before applying. Maintain buffer zones near water sources. Calibrate equipment properly.',
          importance: 'important'
        },
        {
          id: 'ch3',
          title: 'Disposal Protocol',
          description: 'Triple-rinse containers. Dispose of chemicals at authorized facilities. Never reuse chemical containers.',
          importance: 'important'
        }
      ]
    },
    {
      id: 'environmental',
      title: 'Environmental Safety',
      guidelines: [
        {
          id: 'en1',
          title: 'Heat Stress Prevention',
          description: 'Take regular breaks in shade. Drink water every 15 minutes. Watch for signs of heat exhaustion.',
          importance: 'critical'
        },
        {
          id: 'en2',
          title: 'Weather Precautions',
          description: 'Monitor weather forecasts. Have emergency shelter identified. Avoid working in severe weather conditions.',
          importance: 'important'
        },
        {
          id: 'en3',
          title: 'Dust Protection',
          description: 'Use appropriate respiratory protection. Wet down dusty areas when possible. Maintain equipment air filters.',
          importance: 'recommended'
        }
      ]
    }
  ];

  return (
    <div className="max-w-7xl mx-auto">
      <div className="mb-4 sm:mb-8 text-left">
        <h2 className="text-2xl sm:text-3xl font-bold text-green-800 mb-2">Farm Safety Guidelines</h2>
        <p className="text-sm sm:text-base text-gray-600">Essential safety protocols and best practices for agricultural operations</p>
      </div>

      <div className="space-y-4 sm:space-y-8">
        {guidelines.map((category) => (
          <motion.div
            key={category.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-lg shadow-lg p-4 sm:p-6"
          >
            <h3 className="text-lg sm:text-xl font-semibold text-green-700 mb-2 sm:mb-4">{category.title}</h3>
            <div className="grid gap-3 sm:gap-4">
              {category.guidelines.map((guideline) => (
                <div
                  key={guideline.id}
                  className="border-l-4 p-3 sm:p-4 bg-gray-50 rounded-r-lg"
                  style={{
                    borderColor:
                      guideline.importance === 'critical'
                        ? '#ef4444'
                        : guideline.importance === 'important'
                        ? '#f59e0b'
                        : '#10b981',
                  }}
                >
                  <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-2 sm:gap-4">
                    <div>
                      <h4 className="text-base sm:text-lg font-semibold text-gray-900">{guideline.title}</h4>
                      <p className="mt-1 text-sm sm:text-base text-gray-600">{guideline.description}</p>
                    </div>
                    <span
                      className={`text-xs sm:text-sm font-semibold px-2 py-1 rounded self-start ${guideline.importance === 'critical' ? 'bg-red-100 text-red-800' : guideline.importance === 'important' ? 'bg-amber-100 text-amber-800' : 'bg-emerald-100 text-emerald-800'}`}
                    >
                      {guideline.importance.charAt(0).toUpperCase() + guideline.importance.slice(1)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default SafetyGuidelines;
