import React, { useState } from 'react';
import { motion } from 'framer-motion';

interface EmergencyContact {
  id: string;
  name: string;
  role: string;
  phone: string;
  available: '24/7' | 'Business Hours' | 'On Call';
}

interface EmergencyProtocol {
  id: string;
  title: string;
  steps: string[];
  type: 'medical' | 'fire' | 'chemical' | 'equipment';
}

const EmergencyProtocols: React.FC = () => {
  const [selectedProtocol, setSelectedProtocol] = useState<string>('all');

  const emergencyContacts: EmergencyContact[] = [
    {
      id: 'ec1',
      name: 'Local Emergency Services',
      role: 'First Responders',
      phone: '911',
      available: '24/7'
    },
    {
      id: 'ec2',
      name: 'Poison Control Center',
      role: 'Chemical Emergency',
      phone: '1-800-222-1222',
      available: '24/7'
    },
    {
      id: 'ec3',
      name: 'Farm Safety Coordinator',
      role: 'Internal Safety Manager',
      phone: '555-0123',
      available: 'Business Hours'
    },
    {
      id: 'ec4',
      name: 'Equipment Service',
      role: 'Machinery Support',
      phone: '555-0124',
      available: 'On Call'
    }
  ];

  const protocols: EmergencyProtocol[] = [
    {
      id: 'med1',
      title: 'Medical Emergency Response',
      type: 'medical',
      steps: [
        'Assess the scene for safety and potential hazards',
        'Call emergency services (911) immediately',
        'Provide first aid if trained and safe to do so',
        'Send someone to guide emergency vehicles to the location',
        'Notify farm safety coordinator',
        'Document the incident'
      ]
    },
    {
      id: 'fire1',
      title: 'Fire Emergency Protocol',
      type: 'fire',
      steps: [
        'Evacuate all personnel from the area immediately',
        'Call fire department (911)',
        'Use fire extinguisher only if fire is small and you are trained',
        'Shut off equipment and fuel sources if safe to do so',
        'Meet at designated assembly point',
        'Account for all personnel'
      ]
    },
    {
      id: 'chem1',
      title: 'Chemical Exposure Response',
      type: 'chemical',
      steps: [
        'Remove affected person from exposure area',
        'Remove contaminated clothing if safe to do so',
        'Flush affected area with clean water for 15 minutes',
        'Call Poison Control Center',
        'Retrieve Safety Data Sheet (SDS) for the chemical',
        'Seek immediate medical attention'
      ]
    },
    {
      id: 'eq1',
      title: 'Equipment Emergency Protocol',
      type: 'equipment',
      steps: [
        'Shut down equipment immediately using emergency stop',
        'Assess for injuries and call 911 if needed',
        'Secure the area to prevent further incidents',
        'Document equipment condition and incident details',
        'Contact equipment service for assessment',
        'Review and update safety procedures'
      ]
    }
  ];

  const filteredProtocols = selectedProtocol === 'all' 
    ? protocols 
    : protocols.filter(p => p.type === selectedProtocol);

  return (
    <div className="max-w-7xl mx-auto p-2 sm:p-6">
      <div className="mb-4 sm:mb-8 text-left">
        <h2 className="text-2xl sm:text-3xl font-bold text-green-800 mb-2">Emergency Response Protocols</h2>
        <p className="text-sm sm:text-base text-gray-600">Quick access to emergency procedures and important contacts</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 sm:gap-6 mb-4 sm:mb-8">
        {emergencyContacts.map((contact) => (
          <motion.div
            key={contact.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-lg shadow-lg p-4 sm:p-6"
          >
            <h3 className="text-base sm:text-lg font-semibold text-gray-800">{contact.name}</h3>
            <p className="text-xs sm:text-sm text-gray-500">{contact.role}</p>
            <div className="mt-3 sm:mt-4">
              <p className="text-lg sm:text-xl font-bold text-green-600">{contact.phone}</p>
              <span
                className={`text-xs sm:text-sm ${contact.available === '24/7' ? 'text-green-600' : contact.available === 'Business Hours' ? 'text-blue-600' : 'text-orange-600'}`}
              >
                {contact.available}
              </span>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="mb-4 sm:mb-6">
        <select
          className="w-full sm:w-auto p-2 border rounded-lg bg-white text-sm sm:text-base"
          value={selectedProtocol}
          onChange={(e) => setSelectedProtocol(e.target.value)}
        >
          <option value="all">All Protocols</option>
          <option value="medical">Medical Emergencies</option>
          <option value="fire">Fire Emergencies</option>
          <option value="chemical">Chemical Emergencies</option>
          <option value="equipment">Equipment Emergencies</option>
        </select>
      </div>

      <div className="space-y-6">
        {filteredProtocols.map((protocol) => (
          <motion.div
            key={protocol.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-white rounded-lg shadow-lg p-6"
          >
            <div className="flex items-center gap-2 mb-4">
              <span
                className={`w-3 h-3 rounded-full ${
                  protocol.type === 'medical'
                    ? 'bg-red-500'
                    : protocol.type === 'fire'
                    ? 'bg-orange-500'
                    : protocol.type === 'chemical'
                    ? 'bg-yellow-500'
                    : 'bg-blue-500'
                }`}
              />
              <h3 className="text-xl font-semibold text-gray-800">{protocol.title}</h3>
            </div>
            <ol className="list-decimal list-inside space-y-2">
              {protocol.steps.map((step, index) => (
                <li key={index} className="text-gray-600">
                  {step}
                </li>
              ))}
            </ol>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default EmergencyProtocols;
