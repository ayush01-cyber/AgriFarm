import React, { useState } from 'react';
import { motion } from 'framer-motion';

interface ChecklistItem {
  id: string;
  text: string;
  category: string;
  completed: boolean;
}

const SafetyChecklistPortal: React.FC = () => {
  const [checklist, setChecklist] = useState<ChecklistItem[]>([
    // Agricultural safety checklist items
    { id: '1', text: 'Check and use Personal Protective Equipment (PPE)', category: 'Personal Protection', completed: false },
    { id: '2', text: 'Inspect pesticide storage area safety', category: 'Chemical Safety', completed: false },
    { id: '3', text: 'Verify agricultural equipment safety', category: 'Equipment Safety', completed: false },
    { id: '4', text: 'Ensure first aid kit availability', category: 'Emergency Preparedness', completed: false },
    { id: '5', text: 'Inspect drainage and irrigation systems', category: 'Infrastructure', completed: false },
    { id: '6', text: 'Check fire safety equipment', category: 'Emergency Preparedness', completed: false },
    { id: '7', text: 'Review worker safety training records', category: 'Training', completed: false },
    { id: '8', text: 'Verify weather warning system functionality', category: 'Emergency Preparedness', completed: false },
    { id: '9', text: 'Inspect electrical equipment safety', category: 'Equipment Safety', completed: false },
    { id: '10', text: 'Confirm safe water availability', category: 'Basic Amenities', completed: false },
  ]);

  const calculateProgress = () => {
    const completedItems = checklist.filter(item => item.completed).length;
    return (completedItems / checklist.length) * 100;
  };

  const toggleItem = (id: string) => {
    setChecklist(prev =>
      prev.map(item =>
        item.id === id ? { ...item, completed: !item.completed } : item
      )
    );
  };

  return (
    <div className="max-w-4xl mx-auto p-0 sm:p-6">
      <div className="mb-2 sm:mb-6">
        <h2 className="text-2xl font-semibold text-green-700 mb-2 px-2 sm:px-0">Daily Safety Checklist</h2>
        <p className="text-gray-600 px-2 sm:px-0">Please verify all safety standards and mark them when completed</p>
      </div>

      {/* Progress Bar */}
      <div className="mb-4 sm:mb-8 px-2 sm:px-0">
        <div className="flex justify-between mb-2">
          <span className="text-sm font-medium text-gray-700">Progress</span>
          <span className="text-sm font-medium text-green-600">{Math.round(calculateProgress())}%</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2.5">
          <motion.div
            className="bg-green-500 h-2.5 rounded-full"
            initial={{ width: "0%" }}
            animate={{ width: `${calculateProgress()}%` }}
            transition={{ duration: 0.5 }}
          />
        </div>
      </div>

      {/* Checklist Items */}
      <div className="space-y-2 sm:space-y-3 px-2 sm:px-0">
        {checklist.map(item => (
          <motion.div
            key={item.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center p-4 bg-white rounded-lg shadow-sm border border-gray-100 hover:border-green-200 transition-colors"
          >
            <input
              type="checkbox"
              checked={item.completed}
              onChange={() => toggleItem(item.id)}
              className="w-5 h-5 text-green-600 border-gray-300 rounded focus:ring-green-500"
            />
            <div className="ml-4 flex-1">
              <p className="text-gray-800">{item.text}</p>
              <span className="text-sm text-gray-500">{item.category}</span>
            </div>
            {item.completed && (
              <motion.svg
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="w-6 h-6 text-green-500"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M5 13l4 4L19 7"
                />
              </motion.svg>
            )}
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default SafetyChecklistPortal;
