import React, { useState } from 'react';
import { motion } from 'framer-motion';

const AboutContact: React.FC = () => {
  const [activeSection, setActiveSection] = useState<string>('about');

  // Team members with colors and more prominent rounded corners
  const teamMembers = [
    {
      name: 'Yash Aggarwal',
      role: 'Lead Project & Research Analyst and Programmer',
      bio: 'Leading the project with expertise in research analysis and programming in finance .',
      image: '👨‍💻',
      color: 'bg-blue-50',
      corners: 'rounded-tl-3xl rounded-br-3xl' // More prominent top-left and bottom-right rounded
    },
    {
      name: 'Yuvansh Raj Saxena',
      role: 'Research Analyst & Programmer',
      bio: 'Specializing in research analysis and software development of soil analysis.',
      image: '🧑‍💻',
      color: 'bg-purple-50',
      corners: 'rounded-tr-3xl rounded-bl-3xl' // More prominent top-right and bottom-left rounded
    },
    {
      name: 'Anchit Jain',
      role: 'Research Analyst & Programmer',
      bio: 'Expert in research analysis and programming solutions of plantation.',
      image: '👨‍💻',
      color: 'bg-yellow-50',
      corners: 'rounded-tl-3xl rounded-br-3xl' // More prominent top-left and bottom-right rounded
    },
    {
      name: 'Mridang Lalwani',
      role: 'Research Analyst & Programmer',
      bio: 'Focused on research analysis and programming implementation of marketplace and inventory management.',
      image: '🧑‍💻',
      color: 'bg-pink-50',
      corners: 'rounded-tr-3xl rounded-bl-3xl' // More prominent top-right and bottom-left rounded
    },
    {
      name: 'Safina Khatun',
      role: 'Research Analyst & Programmer',
      bio: 'Dedicated to research analysis and programming development of marketplace and inventory management',
      image: '👩‍💻',
      color: 'bg-teal-50',
      corners: 'rounded-tl-3xl rounded-br-3xl' // More prominent top-left and bottom-right rounded
    },
    {
      name: 'Aryan Rana',
      role: 'Research Analyst & Programmer',
      bio: 'Specializing in research analysis and programming solutions of plantation and health and safety.',
      image: '🧑‍💻',
      color: 'bg-indigo-50',
      corners: 'rounded-tr-3xl rounded-bl-3xl' // More prominent top-right and bottom-left rounded
    },
    {
      name: 'Yashisingh Ashoksingh Chauhan',
      role: 'Research Analyst & Programmer',
      bio: 'Expert in research analysis and programming implementation of weather analysis.',
      image: '👨‍💻',
      color: 'bg-orange-50',
      corners: 'rounded-tl-3xl rounded-br-3xl' // More prominent top-left and bottom-right rounded
    },
    {
      name: 'Shreya Dayal',
      role: 'Research Analyst & Programmer',
      bio: 'Focused on research analysis and programming development of weather analysis.',
      image: '👩‍💻',
      color: 'bg-red-50',
      corners: 'rounded-tr-3xl rounded-bl-3xl' // More prominent top-right and bottom-left rounded
    },
    {
      name: 'Soham Dange',
      role: 'Research Analyst & Programmer',
      bio: 'Specializing in research analysis and programming solutions of soil analysis.',
      image: '🧑‍💻',
      color: 'bg-green-50',
      corners: 'rounded-tl-3xl rounded-br-3xl' // More prominent top-left and bottom-right rounded
    },
    {
      name: 'Ayush Kumar Priaydarshi',
      role: 'Research Analyst & Programmer',
      bio: 'Expert in research analysis of finance.',
      image: '👨‍💻',
      color: 'bg-cyan-50',
      corners: 'rounded-tr-3xl rounded-bl-3xl' // More prominent top-right and bottom-left rounded
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-2 sm:px-6 lg:px-8 py-4 min-h-screen bg-gray-50">
      {/* Tab Navigation - Enhanced with gradient */}
      <div className="mb-10 flex justify-center">
        <div className="bg-white p-1 rounded-lg shadow-md inline-flex space-x-1">
          <button
            onClick={() => setActiveSection('about')}
            className={`px-6 py-3 rounded-lg text-sm font-medium transition-all ${
              activeSection === 'about' 
                ? 'bg-gradient-to-r from-green-400 to-green-600 text-white shadow-inner' 
                : 'bg-white text-gray-700 hover:bg-gray-50'
            }`}
          >
            About Us
          </button>
          <button
            onClick={() => setActiveSection('contact')}
            className={`px-6 py-3 rounded-lg text-sm font-medium transition-all ${
              activeSection === 'contact' 
                ? 'bg-gradient-to-r from-green-400 to-green-600 text-white shadow-inner' 
                : 'bg-white text-gray-700 hover:bg-gray-50'
            }`}
          >
            Contact Us
          </button>
        </div>
      </div>

      {/* Content Section */}
      <motion.div
        key={activeSection}
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -10 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="bg-white rounded-2xl p-4 sm:p-6 shadow-lg"
      >
        {activeSection === 'about' ? (
          <div className="space-y-8">
            {/* Mission Section - Enhanced with icon */}
            <section className="text-center mb-12 relative">
              <div className="absolute left-1/2 -top-12 transform -translate-x-1/2 bg-green-100 rounded-full p-4 border-4 border-white shadow-lg">
                <span className="text-4xl">🌱</span>
              </div>
              <h2 className="text-3xl font-bold text-green-700 mb-4 pt-6">About Us</h2>
              <div className="w-20 h-1 bg-gradient-to-r from-green-300 to-green-600 mx-auto mb-4 rounded-full"></div>
              <p className="text-gray-600 max-w-3xl mx-auto">
                At AgriVision, we are dedicated to empowering farmers with innovative technology solutions that enhance productivity, sustainability, and profitability. Our mission is to bridge the gap between traditional farming practices and modern agricultural technology, making smart farming accessible to all.
              </p>
            </section>

            {/* About Us Content - Made more visually interesting */}
            <section className="mb-12">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="bg-gradient-to-br from-green-50 to-green-100 p-6 rounded-tl-3xl rounded-br-3xl shadow-md border-l-4 border-green-400">
                  <h3 className="text-xl font-semibold text-green-800 mb-3 flex items-center">
                    <span className="mr-2">📖</span> Our Story
                  </h3>
                  <p className="text-gray-600">
                    Founded in 2024, AgriVision emerged as an innovative college project focused on environmental management and sustainable agriculture. What began as a collaborative effort between passionate students has evolved into a comprehensive platform dedicated to promoting sustainable farming practices and environmental conservation. Our team of dedicated students from various disciplines came together with a shared vision of creating a positive impact on agricultural sustainability.
                  </p>
                </div>
                <div className="bg-gradient-to-br from-green-50 to-green-100 p-6 rounded-tr-3xl rounded-bl-3xl shadow-md border-r-4 border-green-400">
                  <h3 className="text-xl font-semibold text-green-800 mb-3 flex items-center">
                    <span className="mr-2">🔍</span> Our Approach
                  </h3>
                  <p className="text-gray-600">
                    We believe in a student-driven approach, developing solutions based on thorough research and practical implementation. By combining academic knowledge with modern technology, we create tools that address real-world environmental challenges in agriculture. Our project focuses on integrating sustainable practices with technological innovation to create a more environmentally conscious farming ecosystem.
                  </p>
                </div>
              </div>
            </section>

            {/* Team Section - Made uniform size with prominent corners */}
            <section>
              <h2 className="text-3xl font-bold text-green-700 text-center mb-3">Our Team</h2>
              <div className="w-20 h-1 bg-gradient-to-r from-green-300 to-green-600 mx-auto mb-10 rounded-full"></div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
                {teamMembers.map((member, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: index * 0.1, ease: "easeOut" }}
                    className={`${member.color} border border-gray-200 p-6 shadow-md hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1 ${member.corners} h-full`}
                  >
                    <div className={`text-5xl mb-4 mx-auto flex items-center justify-center w-20 h-20 rounded-full bg-white shadow-inner p-2 border-2 ${index % 2 === 0 ? 'border-green-300' : 'border-blue-300'}`}>
                      {member.image}
                    </div>
                    <h3 className="text-xl font-bold text-gray-800 text-center mb-2">{member.name}</h3>
                    <div className="w-12 h-1 bg-green-400 mx-auto mb-3 rounded-full"></div>
                    <p className={`text-sm font-semibold mb-3 text-center ${index % 2 === 0 ? 'text-green-600' : 'text-blue-600'}`}>{member.role}</p>
                    <p className="text-gray-600 text-sm leading-relaxed">{member.bio}</p>
                  </motion.div>
                ))}
              </div>
            </section>
          </div>
        ) : (
          <div className="max-w-3xl mx-auto">
            <h2 className="text-2xl font-bold text-green-700 mb-6 text-center">Get In Touch</h2>
            <div className="w-20 h-1 bg-gradient-to-r from-green-300 to-green-600 mx-auto mb-8 rounded-full"></div>
            
            {/* Contact Information */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <div className="bg-gradient-to-br from-green-50 to-green-100 p-6 rounded-tl-3xl rounded-br-3xl shadow-md">
                <h3 className="text-lg font-semibold text-green-800 mb-3">Contact Information</h3>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <span className="text-green-600 mr-2">📍</span>
                    <span className="text-gray-600">123 Agricultural Hub, Bhopal, Madhya Pradesh 462003</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 mr-2">📞</span>
                    <span className="text-gray-600">+91 98765 43210</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 mr-2">✉️</span>
                    <span className="text-gray-600">contact@agrivision.in</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 mr-2">⏰</span>
                    <span className="text-gray-600">Monday - Saturday: 9:00 AM - 6:00 PM</span>
                  </li>
                </ul>
              </div>
              
              <div className="bg-gradient-to-br from-green-50 to-green-100 p-6 rounded-tr-3xl rounded-bl-3xl shadow-md">
                <h3 className="text-lg font-semibold text-green-800 mb-3">Support Channels</h3>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <span className="text-green-600 mr-2">🌐</span>
                    <span className="text-gray-600">Visit our Help Center for FAQs and guides</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 mr-2">📱</span>
                    <span className="text-gray-600">WhatsApp Support: +91 98765 43210</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 mr-2">👨‍🌾</span>
                    <span className="text-gray-600">Join our Farmer Community Forum</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 mr-2">📅</span>
                    <span className="text-gray-600">Schedule a demo or training session</span>
                  </li>
                </ul>
              </div>
            </div>
            
            {/* Contact Form */}
            <div className="bg-white border-2 border-green-100 rounded-tl-3xl rounded-br-3xl p-6 shadow-md">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Get in Touch</h3>
              <div className="text-gray-600 mb-6">
                <p>We'd love to hear from you! Please click the button below to fill out our Google form. We'll get back to you as soon as possible.</p>
              </div>
              <a
                href="https://forms.gle/eSh6DioNczu1HHSS6"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block w-full text-center px-6 py-3 bg-gradient-to-r from-green-500 to-green-600 text-white font-medium rounded-tl-lg rounded-br-lg hover:from-green-600 hover:to-green-700 transition-all focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2"
              >
                Contact Us via Google Form
              </a>
            </div>
          </div>
        )}
      </motion.div>
    </div>
  );
};

export default AboutContact;