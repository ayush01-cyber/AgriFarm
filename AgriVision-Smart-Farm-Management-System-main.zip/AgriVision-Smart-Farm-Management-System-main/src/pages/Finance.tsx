import { useState, useEffect } from 'react';
import financialData from '../data/financialSchemes.json';
import { motion, AnimatePresence } from 'framer-motion';

const schemeLinks: { [key: string]: string } = {
  "PM-KISAN": "https://pmkisan.gov.in/",
  "Kisan Credit Card (KCC)": "https://www.nabard.org/content1.aspx?id=1720&catid=23&mid=530",
  "Pradhan Mantri Fasal Bima Yojana (PMFBY)": "https://pmfby.gov.in/",
  "Interest Subvention Scheme (ISS)": "https://agricoop.nic.in/en/divisiontype/credit",
  "Mudra Loan - Shishu": "https://www.mudra.org.in/",
  "Mudra Loan - Kishor": "https://www.mudra.org.in/",
  "Mudra Loan - Tarun": "https://www.mudra.org.in/"
};

const Finance = () => {
  const [selectedIncome, setSelectedIncome] = useState<string>(financialData.incomeRanges[0]);

  useEffect(() => {
    // Add Chatling chatbot script
    const chatlingConfigScript = document.createElement('script');
    chatlingConfigScript.innerHTML = 'window.chtlConfig = { chatbotId: "4778352444" }';
    document.head.appendChild(chatlingConfigScript);

    const chatlingEmbedScript = document.createElement('script');
    chatlingEmbedScript.async = true;
    chatlingEmbedScript.id = 'chatling-embed-script';
    chatlingEmbedScript.type = 'text/javascript';
    chatlingEmbedScript.src = 'https://chatling.ai/js/embed.js';
    chatlingEmbedScript.setAttribute('data-id', '4778352444');
    document.body.appendChild(chatlingEmbedScript);

    // Cleanup on unmount
    return () => {
      const configScript = document.querySelector('script[innerHTML*="window.chtlConfig"]');
      const embedScript = document.getElementById('chatling-embed-script');
      if (configScript) document.head.removeChild(configScript);
      if (embedScript) document.body.removeChild(embedScript);
    };
  }, []);

  const quickQuestions = [
    "What is PM-KISAN scheme?",
    "How to apply for Kisan Credit Card?",
    "What are the benefits of Fasal Bima Yojana?",
    "Eligibility for Mudra loan?",
    "Maximum loan amount under KCC scheme?"
  ];

  return (
    <div className="max-w-7xl mx-auto px-1 sm:px-6 lg:px-8 py-2 sm:py-4 min-h-screen">
      <AnimatePresence mode="wait" initial={false}>
        <motion.div
          key="finance-content"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.4, ease: 'easeInOut' }}
          className="bg-white rounded-2xl p-2 sm:p-6 shadow-lg max-w-5xl mx-auto"
        >
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.4, delay: 0.2, ease: 'easeOut' }}
            className="max-w-2xl mx-auto mb-10"
          >
            <div className="text-center mb-2 sm:mb-4">
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.8 }}
                className="relative"
              >
                <motion.h2 
                  initial={{ opacity: 0, scale: 0.5 }}
                  animate={{ 
                    opacity: 1, 
                    scale: 1,
                    color: ['#1f2937', '#047857', '#1f2937'],
                    textShadow: ['0 0 0px rgba(4,120,87,0)', '0 0 20px rgba(4,120,87,0.5)', '0 0 0px rgba(4,120,87,0)']
                  }}
                  transition={{ 
                    duration: 1,
                    scale: {
                      type: "spring",
                      stiffness: 200,
                      damping: 10
                    },
                    color: {
                      repeat: Infinity,
                      duration: 3,
                      ease: "easeInOut"
                    },
                    textShadow: {
                      repeat: Infinity,
                      duration: 3,
                      ease: "easeInOut"
                    }
                  }}
                  className="text-xl sm:text-3xl font-bold relative"
                >
                  {'Financial Schemes'.split('').map((letter, index) => (
                    <motion.span
                      key={index}
                      initial={{ opacity: 0, y: -50 }}
                      animate={{ 
                        opacity: 1, 
                        y: 0,
                        rotateX: [0, 360, 0],
                        scale: [1, 1.2, 1]
                      }}
                      transition={{
                        duration: 0.8,
                        delay: index * 0.08,
                        rotateX: {
                          duration: 0.8,
                          delay: index * 0.08,
                          ease: "easeInOut"
                        },
                        scale: {
                          duration: 0.4,
                          delay: index * 0.08,
                          ease: "easeInOut"
                        }
                      }}
                      className="inline-block transform-gpu"
                      style={{ 
                        transformStyle: 'preserve-3d',
                        backfaceVisibility: 'hidden'
                      }}
                    >
                      {letter === ' ' ? '\u00A0' : letter}
                    </motion.span>
                  ))}
                </motion.h2>
              </motion.div>
              <motion.p 
                initial={{ opacity: 0, y: -10 }}
                animate={{ 
                  opacity: 1, 
                  y: 0,
                  color: ['#4b5563', '#059669', '#4b5563']
                }}
                transition={{ 
                  duration: 0.6,
                  delay: 1.5,
                  color: {
                    repeat: Infinity,
                    duration: 3,
                    delay: 1.5,
                    ease: "easeInOut"
                  }
                }}
                className="text-sm sm:text-base mt-3"
              >
                {'Explore various government and financial schemes available for farmers'.split('').map((letter, index) => (
                  <motion.span
                    key={index}
                    initial={{ opacity: 0, y: 20, scale: 0.5 }}
                    animate={{ 
                      opacity: 1, 
                      y: 0, 
                      scale: 1,
                      rotateY: [0, 360],
                    }}
                    transition={{
                      duration: 0.5,
                      delay: 2 + (index * 0.03),
                      rotateY: {
                        duration: 0.8,
                        delay: 2 + (index * 0.03),
                        ease: "easeOut"
                      }
                    }}
                    className="inline-block transform-gpu"
                    style={{ 
                      transformStyle: 'preserve-3d',
                      backfaceVisibility: 'hidden'
                    }}
                  >
                    {letter === ' ' ? '\u00A0' : letter}
                  </motion.span>
                ))}
              </motion.p>
            </div>

            {/* Income Range Selection */}
            <div className="-mx-1 px-1 sm:-mx-4 sm:px-4 mb-4 sm:mb-6 overflow-x-auto hide-scrollbar">
              <div className="flex gap-1 sm:gap-3 sm:justify-center min-w-max pb-2">
                {financialData.incomeRanges.map((range, index) => (
                  <motion.button
                    key={range}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.1 }}
                    onClick={() => setSelectedIncome(range)}
                    className={`px-2 sm:px-6 py-2 sm:py-3 text-xs sm:text-sm font-medium rounded-xl sm:rounded-2xl transition-all duration-200 border-2 min-w-[6.25rem] sm:min-w-[7.5rem]
                      ${selectedIncome === range
                        ? 'bg-green-500 text-white border-green-500 shadow-md transform scale-[1.02]'
                        : 'bg-white text-gray-700 border-gray-300 hover:border-green-500 hover:text-green-500'}
                      active:scale-95 touch-manipulation`}
                  >
                    {range}
                  </motion.button>
                ))}
              </div>
            </div>

            {/* Schemes Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 relative">
              <AnimatePresence mode="wait" initial={false}>
                {financialData.schemeData[selectedIncome as keyof typeof financialData.schemeData]?.map((scheme, index) => (
                  <motion.div
                    key={scheme.name}
                    initial={{ 
                      opacity: 0,
                      x: index % 2 === 0 ? -100 : 100,
                      y: 50,
                      scale: 0.8,
                      rotateY: index % 2 === 0 ? -45 : 45
                    }}
                    animate={{ 
                      opacity: 1,
                      x: 0,
                      y: 0,
                      scale: 1,
                      rotateY: 0
                    }}
                    exit={{ 
                      opacity: 0,
                      x: index % 2 === 0 ? -100 : 100,
                      y: 50,
                      scale: 0.8,
                      rotateY: index % 2 === 0 ? -45 : 45
                    }}
                    transition={{ 
                      duration: 0.6,
                      delay: index * 0.15,
                      type: "spring",
                      stiffness: 100,
                      damping: 12
                    }}
                    whileHover={{ 
                      scale: 1.02,
                      y: -5,
                      transition: { duration: 0.2 }
                    }}
                    className="bg-white/80 backdrop-blur-xl rounded-xl sm:rounded-2xl shadow-[0_4px_20px_rgb(0,0,0,0.03)] p-2 sm:p-6 hover:shadow-[0_4px_25px_rgb(0,0,0,0.1)] transition-all duration-200 border border-gray-200/50 transform-gpu"
                  >
                    <motion.h3 
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.15 + 0.3 }}
                      className="text-lg sm:text-xl font-semibold text-gray-800 mb-2 sm:mb-3 border-b border-gray-100 pb-2"
                    >
                      <motion.a
                        href={schemeLinks[scheme.name]}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="hover:text-green-600 transition-colors duration-200 flex items-center gap-2"
                        whileHover={{ scale: 1.02 }}
                      >
                        {scheme.name}
                        <motion.svg
                          whileHover={{ x: 3 }}
                          className="w-4 h-4 inline-block"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"
                          />
                        </motion.svg>
                      </motion.a>
                    </motion.h3>
                    <motion.div 
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: index * 0.15 + 0.4 }}
                      className="space-y-3 sm:space-y-4"
                    >
                      <motion.p 
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.15 + 0.5 }}
                        className="text-sm sm:text-base text-gray-600"
                      >
                        <span className="font-medium text-gray-700">Eligibility:</span> {scheme.eligibility}
                      </motion.p>
                      <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.15 + 0.6 }}
                        className="bg-green-50 p-3 sm:p-4 rounded-lg"
                      >
                        <p className="font-medium text-sm sm:text-base text-green-700 mb-1 sm:mb-2">Pros:</p>
                        <ul className="list-disc list-inside text-xs sm:text-sm text-gray-600 space-y-0.5 sm:space-y-1">
                          {scheme.pros.map((pro, proIndex) => (
                            <motion.li
                              key={proIndex}
                              initial={{ opacity: 0, x: -20 }}
                              animate={{ opacity: 1, x: 0 }}
                              transition={{ delay: index * 0.15 + 0.7 + (proIndex * 0.1) }}
                            >
                              {pro}
                            </motion.li>
                          ))}
                        </ul>
                      </motion.div>
                      <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.15 + 0.8 }}
                        className="bg-red-50 p-3 sm:p-4 rounded-lg"
                      >
                        <p className="font-medium text-sm sm:text-base text-red-700 mb-1 sm:mb-2">Cons:</p>
                        <ul className="list-disc list-inside text-xs sm:text-sm text-gray-600 space-y-0.5 sm:space-y-1">
                          {scheme.cons.map((con, conIndex) => (
                            <motion.li
                              key={conIndex}
                              initial={{ opacity: 0, x: -20 }}
                              animate={{ opacity: 1, x: 0 }}
                              transition={{ delay: index * 0.15 + 0.9 + (conIndex * 0.1) }}
                            >
                              {con}
                            </motion.li>
                          ))}
                        </ul>
                      </motion.div>
                    </motion.div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>

            {/* Quick Questions */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.6 }}
              className="mt-6"
            >
              <motion.p
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: 0.8 }}
                className="text-sm text-gray-600 mb-2"
              >
                Popular Questions:
              </motion.p>
              <div className="flex gap-2 overflow-x-auto pb-2 snap-x">
                {quickQuestions.map((q, index) => (
                  <motion.button
                    key={q}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    transition={{ duration: 0.3, delay: index * 0.1 + 0.8 }}
                    className={`flex-none px-2 sm:px-4 py-1 sm:py-2 text-xs sm:text-sm bg-gray-100 text-gray-700 hover:bg-gray-200 cursor-pointer rounded-full transition-colors duration-200 snap-center whitespace-nowrap`}
                  >
                    {q}
                  </motion.button>
                ))}
              </div>
            </motion.div>
          </motion.div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
};

export default Finance;