import { useState, useEffect } from 'react';
import { WeatherData } from '../types/types';
import { motion } from 'framer-motion';
import { useRef } from 'react';

const SOIL_TYPES = {
  "Black Cotton": "Black Cotton",
  "Red-Yellow": "Red-Yellow",
  "Alluvial": "Alluvial",
  "Laterite": "Laterite",
  "Sandy": "Sandy"
};

const LoadingSpinner = () => (
  <div className="flex items-center justify-center min-h-[80dvh]">
    <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-gray-900"></div>
  </div>
);

const SoilAnalysisContent = () => {
  const [weatherData, setWeatherData] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState(true);

  // Load saved soil type from localStorage or use default
  const [selectedSoilType, setSelectedSoilType] = useState<keyof typeof SOIL_TYPES>(() => {
    const saved = localStorage.getItem('selectedSoilType');
    return (saved as keyof typeof SOIL_TYPES) || "Black Cotton";
  });

  const handleSoilTypeChange = (value: keyof typeof SOIL_TYPES) => {
    setSelectedSoilType(value);
  };

  // Create ref for soil description section
  const soilDescriptionRef = useRef<HTMLDivElement>(null);

  // Save soil type to localStorage when it changes
  useEffect(() => {
    localStorage.setItem('selectedSoilType', selectedSoilType);
  }, [selectedSoilType]);


  // Weather API configuration
  const WEATHER_API_KEY = '4c636959f90af861f18acaf1eb66a745';
  const WEATHER_API_URL = 'https://api.openweathermap.org/data/2.5/weather';
  const CITY = 'Bhopal';
  
  const fetchWeatherData = async () => {
    try {
      const response = await fetch(
        `${WEATHER_API_URL}?q=${CITY}&appid=${WEATHER_API_KEY}&units=metric`
      );
      
      if (!response.ok) {
        throw new Error('Weather data fetch failed');
      }
      const data = await response.json();
      return {
        temperature: Math.round(data.main.temp),
        condition: data.weather[0].main,
        humidity: data.main.humidity,
        windSpeed: data.wind.speed,
        description: data.weather[0].description
      };
    } catch (error) {
      console.error('Error fetching weather data:', error);
      return {
        temperature: 32,
        condition: 'Sunny',
        humidity: 65,
        windSpeed: 5,
        description: 'Clear sky'
      };
    }
  };

  const getSoilDescription = (soilType: string) => {
    switch(soilType) {
      case "Black Cotton":
        return "Rich in clay, retains moisture well. High in calcium, magnesium, and iron. Cracks in summer help aeration.";
      case "Red-Yellow":
        return "Well-drained but low in nutrients. Requires fertilizers for optimal productivity. Found in hilly and forested regions.";
      case "Alluvial":
        return "Highly fertile, rich in minerals. Supports a variety of crops. Found near riverbanks.";
      case "Laterite":
        return "Reddish due to iron oxide, acidic in nature. Found in plateau regions, needs fertilizers for high yields.";
      case "Sandy":
        return "Loose and well-drained, but low in nutrients. Poor water retention, requiring frequent irrigation. Warms up quickly, making it suitable for early planting.";
      default:
        return "";
    }
  };

  const getRecommendedCrops = (soilType: string) => {
    switch(soilType) {
      case "Black Cotton":
        return [
          { name: "Cotton", description: "Thrives in warm climate, requires 6-8 months growing season. Best planted in early summer with moderate irrigation." },
          { name: "Soybean", description: "Fast-growing crop (3-4 months), needs well-drained soil. Plant during monsoon season for optimal yields." },
          { name: "Pulses", description: "Drought-resistant, improves soil fertility. Ideal for rotation farming with 3-4 month growing period." }
        ];
      case "Red-Yellow":
        return [
          { name: "Maize", description: "Requires warm weather, full sun exposure. 3-4 month growing period with regular irrigation." },
          { name: "Groundnut", description: "Grows well in light soil, needs 4-5 months. Best planted in early monsoon or spring." },
          { name: "Millets", description: "Drought-tolerant, quick growing (70-100 days). Excellent for sustainable farming." }
        ];
      case "Alluvial":
        return [
          { name: "Wheat", description: "Cool-season crop (4-5 months), needs moderate irrigation. Best planted in winter season." },
          { name: "Rice", description: "Requires abundant water, warm climate. 3-6 months growing period depending on variety." },
          { name: "Sugarcane", description: "Long duration crop (12-18 months), needs regular irrigation. Prefers tropical climate." }
        ];
      case "Laterite":
        return [
          { name: "Banana", description: "Year-round crop, needs good drainage. Takes 9-12 months from planting to harvest." },
          { name: "Cashew", description: "Perennial tree crop, drought-resistant. Starts yielding after 3-4 years." },
          { name: "Millets", description: "Hardy crop, tolerates acidic soil. Short duration (3-4 months) with minimal inputs." }
        ];
      case "Sandy":
        return [
          { name: "Groundnut", description: "Well-suited for sandy soils, 4-5 month duration. Needs regular but moderate watering." },
          { name: "Carrots", description: "Root vegetable, 70-80 days to mature. Requires deep, loose soil for proper growth." },
          { name: "Watermelon", description: "Summer crop, needs 3-4 months. Thrives in well-drained soil with full sun exposure." }
        ];
      default:
        return [];
    }
  };

  const getFertilizerRecommendations = (soilType: string): string[] => {
    switch(soilType) {
      case "Black Cotton":
        return ["Organic manure", "Phosphorus & potash-based fertilizers"];
      case "Red-Yellow":
        return ["Nitrogen-rich fertilizers", "Organic compost"];
      case "Alluvial":
        return ["Potassium & phosphorus-based fertilizers"];
      case "Laterite":
        return ["Lime to reduce acidity", "Organic compost"];
      case "Sandy":
        return ["Organic matter (compost, manure)", "Nitrogen-rich fertilizers", "Mulching"];
      default:
        return [];
    }
  };

  // Weather condition helper function
  const getWeatherIcon = (condition: string | undefined) => {
    switch(condition?.toLowerCase()) {
      case 'clear':
      case 'sunny':
        return '☀️';
      case 'clouds':
      case 'cloudy':
        return '☁️';
      case 'rain':
        return '🌧️';
      case 'snow':
        return '❄️';
      case 'thunderstorm':
        return '⛈️';
      default:
        return '🌤️';
    }
  };

  useEffect(() => {
    const loadData = async () => {
      try {
        setLoading(true);
        const weather = await fetchWeatherData();
        setWeatherData(weather);
        // Removed unused soilConditions variable
        // Removed setSoilInfo since it's not defined and no longer needed
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, [selectedSoilType]);

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <div className="container mx-auto px-2 sm:px-4 py-3 sm:py-6 max-w-7xl">
      {/* Header Section */}
      <div className="mb-3 sm:mb-6 space-y-2 sm:space-y-4">
        <div className="bg-white rounded-xl sm:rounded-2xl p-2 sm:p-5 shadow-lg">
          <h2 className="text-lg sm:text-xl font-semibold mb-2 sm:mb-4 text-gray-800">What is your soil type?</h2>
          <div className="flex gap-1 sm:gap-3 overflow-x-auto hide-scrollbar pb-1 sm:pb-2 justify-start sm:justify-center" style={{ scrollBehavior: 'smooth' }}>
            {Object.entries(SOIL_TYPES).map(([value, label], index) => (
              <button
                key={value}
                onClick={() => handleSoilTypeChange(value as keyof typeof SOIL_TYPES)}
                className={`px-3 sm:px-6 py-2 sm:py-3 text-xs sm:text-sm font-medium rounded-xl sm:rounded-2xl transition-all duration-200 border-2 flex-shrink-0 sm:flex-1 w-[7.5rem] sm:max-w-[12.5rem] sm:min-w-[9.375rem]
                  ${selectedSoilType === value
                    ? 'bg-green-500 text-white border-green-500 shadow-md transform scale-[1.02]'
                    : 'bg-white text-gray-700 border-gray-300 hover:border-green-500 hover:text-green-500'}
                  active:scale-95 touch-manipulation`}
                style={{
                  transform: selectedSoilType === value ? 'scale(1.02)' : 'scale(1)',
                  transition: 'all 0.6s cubic-bezier(0.34, 1.56, 0.64, 1)'
                }}
              >
                <motion.span
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{
                    type: 'spring',
                    stiffness: 300,
                    damping: 20,
                    delay: index * 0.1
                  }}
                >
                  {label}
                </motion.span>
              </button>
            ))}
          </div>
        </div>

        {/* Weather Card */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ 
            type: "spring",
            stiffness: 100,
            damping: 15,
            duration: 0.6,
            delay: 0.4 
          }}
          className="bg-gradient-to-r from-blue-600 to-blue-400 text-white rounded-xl sm:rounded-2xl p-3 sm:p-5 shadow-lg hover:shadow-xl transition-shadow duration-300"
        >
          <motion.h2
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ 
              type: "spring",
              stiffness: 150,
              damping: 20,
              delay: 0.5 
            }}
            className="text-lg sm:text-xl font-semibold mb-2 sm:mb-3"
          >
            Current Weather
          </motion.h2>
          <div className="flex flex-col space-y-3 sm:space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2 sm:space-x-4">
                <motion.div
                  initial={{ scale: 0, rotate: -180 }}
                  animate={{ scale: 1, rotate: 0 }}
                  transition={{ 
                    type: "spring",
                    stiffness: 260,
                    damping: 20,
                    delay: 0.6 
                  }}
                  className="text-3xl sm:text-5xl"
                >
                  {getWeatherIcon(weatherData?.condition)}
                </motion.div>
                <div>
                  <motion.p
                    initial={{ x: -20, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ 
                      type: "spring",
                      stiffness: 150,
                      damping: 15,
                      delay: 0.7 
                    }}
                    className="text-2xl sm:text-3xl font-semibold"
                  >
                    {weatherData?.temperature}°C <span className="text-sm">📍 {CITY}</span>
                  </motion.p>
                  <motion.p
                    initial={{ x: -20, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ 
                      type: "spring",
                      stiffness: 150,
                      damping: 15,
                      delay: 0.8
                    }}
                    className="text-xs sm:text-sm text-white/90 capitalize"
                  >
                    {weatherData?.description}
                  </motion.p>
                </div>
              </div>
              <motion.div
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ 
                  type: "spring",
                  stiffness: 150,
                  damping: 15,
                  delay: 0.9
                }}
                className="flex flex-col space-y-1 sm:space-y-2 text-xs sm:text-sm">
                <div className="flex items-center space-x-2">
                  <span className="text-white/80">Humidity:</span>
                  <span className="font-medium">{weatherData?.humidity}%</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-white/80">Wind Speed:</span>
                  <span className="font-medium">{weatherData?.windSpeed} km/h</span>
                </div>
              </motion.div>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2 sm:gap-4">
        {/* Soil Description */}
        <motion.div
          ref={soilDescriptionRef}
          initial={{ x: -20, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.5 }}
          whileHover={{ scale: 1.02 }}
          className="bg-white/80 backdrop-blur-md rounded-xl sm:rounded-2xl p-3 sm:p-5 shadow-lg border border-gray-100">
          <h3 className="text-base sm:text-lg font-semibold text-gray-900 mb-2 sm:mb-3">Soil Description</h3>
          <div className="space-y-2">
            <p className="text-sm sm:text-base text-gray-700 leading-relaxed">{getSoilDescription(selectedSoilType)}</p>
          </div>
        </motion.div>

        {/* Recommended Crops */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.6 }}
          whileHover={{ scale: 1.02 }}
          className="bg-white/80 backdrop-blur-md rounded-xl sm:rounded-2xl p-2 sm:p-5 shadow-lg border border-gray-100">
          <h3 className="text-base sm:text-lg font-semibold text-gray-900 mb-2 sm:mb-3">Recommended Crops</h3>
          <div className="space-y-2 sm:space-y-3">
            {getRecommendedCrops(selectedSoilType).map((crop, index) => (
              <div key={index} className="p-2 sm:p-3 bg-green-50 rounded-lg hover:bg-green-100 transition-colors duration-200">
                <p className="text-sm sm:text-base text-green-800 font-medium mb-1">🌱 {crop.name}</p>
                <p className="text-xs sm:text-sm text-green-700">{crop.description}</p>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Fertilizer Recommendations */}
        <motion.div
          initial={{ x: 20, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.7 }}
          whileHover={{ scale: 1.02 }}
          className="bg-white/80 backdrop-blur-md rounded-xl sm:rounded-2xl p-2 sm:p-5 shadow-lg border border-gray-100">
          <h3 className="text-base sm:text-lg font-semibold text-gray-900 mb-2 sm:mb-3">Fertilizer Recommendations</h3>
          <div className="space-y-2">
            {getFertilizerRecommendations(selectedSoilType).map((fertilizer, index) => (
              <div key={index} className="p-2 bg-amber-50 rounded-lg">
                <p className="text-xs sm:text-sm text-amber-800">💫 {fertilizer}</p>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Additional Information */}
        <div className="md:col-span-2 lg:col-span-3 bg-white/80 backdrop-blur-md rounded-xl sm:rounded-2xl p-2 sm:p-5 shadow-lg border border-gray-100">
          <h3 className="text-base sm:text-lg font-semibold text-gray-900 mb-2 sm:mb-3">Soil Management Tips</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 sm:gap-4">
            <div className="p-3 sm:p-4 bg-blue-50 rounded-lg">
              <h4 className="text-sm sm:text-base font-semibold text-blue-900 mb-2">Water Management</h4>
              <ul className="space-y-1 sm:space-y-2 text-xs sm:text-sm text-blue-800">
                <li>• Regular moisture monitoring</li>
                <li>• Proper drainage system</li>
                <li>• Irrigation scheduling</li>
              </ul>
            </div>
            <div className="p-3 sm:p-4 bg-green-50 rounded-lg">
              <h4 className="text-sm sm:text-base font-semibold text-green-900 mb-2">Soil Health</h4>
              <ul className="space-y-1 sm:space-y-2 text-xs sm:text-sm text-green-800">
                <li>• Regular soil testing</li>
                <li>• Organic matter addition</li>
                <li>• pH management</li>
              </ul>
            </div>
            <div className="p-3 sm:p-4 bg-amber-50 rounded-lg">
              <h4 className="text-sm sm:text-base font-semibold text-amber-900 mb-2">Conservation</h4>
              <ul className="space-y-1 sm:space-y-2 text-xs sm:text-sm text-amber-800">
                <li>• Erosion control</li>
                <li>• Crop rotation</li>
                <li>• Mulching practices</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const InfoModal = ({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) => (
  <div className={`fixed inset-0 z-50 ${isOpen ? 'block' : 'hidden'}`}>
    <div className="fixed inset-0 bg-black/50" onClick={onClose} />
    <div className="fixed bottom-0 right-0 m-4 bg-white rounded-lg p-6 max-w-sm shadow-lg">
      <h3 className="text-lg font-semibold mb-2">Information</h3>
      <p className="text-sm text-gray-600">
        The soil analysis data provided on this page is compiled from multiple credible sources, including verified inputs from local farmers, peer-reviewed agricultural research publications, and official data released by government bodies such as the Ministry of Agriculture. By integrating these diverse and authoritative sources, we strive to deliver accurate, up-to-date, and reliable insights to support informed and effective agricultural decision-making.
      </p>
      <button
        className="mt-4 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors"
        onClick={onClose}
      >
        Close
      </button>
    </div>
  </div>
);

const SoilAnalysis = () => {
  const [showInfoModal, setShowInfoModal] = useState(false);

  return (
    <div>
      <button
        className="fixed bottom-4 right-4 p-3 bg-white rounded-full shadow-lg hover:shadow-xl transition-shadow"
        onClick={() => setShowInfoModal(true)}
      >
        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      </button>
      <InfoModal isOpen={showInfoModal} onClose={() => setShowInfoModal(false)} />
      <div className="container mx-auto px-2 sm:px-4 py-3 sm:py-6 max-w-7xl">
        <SoilAnalysisContent />
      </div>
    </div>
  );
};

export default SoilAnalysis;
