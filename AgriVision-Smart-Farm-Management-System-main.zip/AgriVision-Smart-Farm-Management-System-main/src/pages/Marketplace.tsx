import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent } from "../components/Card";
import { Button } from "../components/Button";
import seedsData from "../data/seeds.json";
import fertilizersData from "../data/fertilizers.json";
import machineryData from "../data/machinery.json";
import toolsData from "../data/tools.json";
import pesticidesData from "../data/pesticides.json";
import dripIrrigationData from "../data/drip-irrigation.json";
import soilMaterialData from "../data/soil-material.json";

const categories = ["All", "Seeds", "Fertilizer", "Machinery", "Tools", "Pesticides", "Irrigation", "Soil Material"];
const sortingOptions = ["Price: Low to High", "Price: High to Low", "Name: A-Z", "Name: Z-A", "Rating: High to Low"];

type Product = {
  name: string;
  category: string;
  price: string | number;
  description: string;
  image: string;
  supplier?: string;
  contact?: string;
  website?: string;
  ratings?: { name: string; rating: number; comment: string; date: string }[];
  inStock?: boolean;
  freeShipping?: boolean;
  onSale?: boolean;
};

const Marketplace: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>(() => localStorage.getItem("selectedCategory") || "All");
  const [maxPrice, setMaxPrice] = useState<number | null>(null);
  const [minPrice, setMinPrice] = useState<number | null>(null);
  const [sortOrder, setSortOrder] = useState<string>("");
  const [expandedProductId, setExpandedProductId] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [selectedFilters, setSelectedFilters] = useState<string[]>([]);
  const [ratingFilter, setRatingFilter] = useState<number | null>(null);
  const [allProducts, setAllProducts] = useState<Product[]>([]);

  useEffect(() => {
    // Load all products on component mount
    const allData = [
      ...seedsData.map(product => ({ ...product, category: "Seeds" })),
      ...fertilizersData.map(product => ({ ...product, category: "Fertilizer" })),
      ...machineryData.map(product => ({ ...product, category: "Machinery" })),
      ...toolsData.map(product => ({ ...product, category: "Tools" })),
      ...pesticidesData.map(product => ({ ...product, category: "Pesticides" })),
      ...dripIrrigationData.map(product => ({ ...product, category: "Irrigation" })),
      ...soilMaterialData.map(product => ({ ...product, category: "Soil Material" }))
    ];
    setAllProducts(allData);
  }, []);

  const getProductsByCategory = (category: string): Product[] => {
    if (category === "All") {
      return allProducts;
    }

    const dataMap: Record<string, Product[]> = {
      Seeds: seedsData,
      Fertilizer: fertilizersData,
      Machinery: machineryData,
      Tools: toolsData,
      Pesticides: pesticidesData,
      Irrigation: dripIrrigationData,
      "Soil Material": soilMaterialData
    };
    
    return (dataMap[category] || []).map(product => ({
      ...product,
      category,
      image: product.image || "/images/default-product.jpg"
    }));
  };

  let products = getProductsByCategory(selectedCategory);

  // Apply search filter
  if (searchQuery) {
    products = products.filter(product => 
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.description.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }

  // Apply price filters
  if (maxPrice !== null) {
    products = products.filter(product => Number(product.price) <= maxPrice);
  }
  if (minPrice !== null) {
    products = products.filter(product => Number(product.price) >= minPrice);
  }

  // Apply rating filter
  if (ratingFilter !== null) {
    products = products.filter(product => {
      if (!product.ratings || product.ratings.length === 0) return false;
      const totalRating = product.ratings.reduce((acc, curr) => acc + curr.rating, 0);
      const avgRating = totalRating / product.ratings.length;
      return avgRating >= ratingFilter;
    });
  }

  // Apply additional filters
  if (selectedFilters.length > 0) {
    products = products.filter(product => {
      return selectedFilters.every(filter => {
        switch (filter) {
          case "In Stock": return product.inStock;
          case "Has Reviews": return product.ratings && product.ratings.length > 0;
          case "Free Shipping": return product.freeShipping;
          case "On Sale": return product.onSale;
          default: return true;
        }
      });
    });
  }

  // Apply sorting
  switch (sortOrder) {
    case "Price: Low to High":
      products = [...products].sort((a, b) => Number(a.price) - Number(b.price));
      break;
    case "Price: High to Low":
      products = [...products].sort((a, b) => Number(b.price) - Number(a.price));
      break;
    case "Name: A-Z":
      products = [...products].sort((a, b) => a.name.localeCompare(b.name));
      break;
    case "Name: Z-A":
      products = [...products].sort((a, b) => b.name.localeCompare(a.name));
      break;
    case "Rating: High to Low":
      products = [...products].sort((a, b) => {
        const aRatings = a.ratings || [];
        const bRatings = b.ratings || [];
        
        const avgRatingA = aRatings.length > 0 
          ? aRatings.reduce((acc, curr) => acc + curr.rating, 0) / aRatings.length 
          : 0;
          
        const avgRatingB = bRatings.length > 0 
          ? bRatings.reduce((acc, curr) => acc + curr.rating, 0) / bRatings.length 
          : 0;
          
        return avgRatingB - avgRatingA;
      });
      break;
  }

  const handleCardClick = (index: number) => {
    setExpandedProductId(expandedProductId === index ? null : index);
  };

  // Calculate average rating safely
  const calculateAvgRating = (ratings?: { rating: number }[]): number | null => {
    if (!ratings || ratings.length === 0) return null;
    const total = ratings.reduce((acc, curr) => acc + curr.rating, 0);
    return total / ratings.length;
  };

  // Group products by category for the All view
  const groupedProducts = products.reduce((acc, product) => {
    if (!acc[product.category]) {
      acc[product.category] = [];
    }
    acc[product.category].push(product);
    return acc;
  }, {} as Record<string, Product[]>);

  return (
    <div className="container mx-auto px-2 py-4 max-w-7xl">
      <div className="mb-6 text-center">
        <h1 className="text-3xl font-bold text-green-700">Agricultural Marketplace</h1>
        <p className="text-gray-600">Find quality farming products at the best prices</p>
      </div>
      
      <div className="mb-4 space-y-3">
        <div className="bg-white rounded-xl p-4 shadow-lg">
          <h2 className="text-xl font-semibold mb-3 text-gray-800">Select a Category</h2>
          <div className="flex gap-2 overflow-x-auto hide-scrollbar pb-1 justify-center">
            {categories.map((category, index) => (
              <button
                key={category}
                onClick={() => {
                  setSelectedCategory(category);
                  localStorage.setItem("selectedCategory", category);
                  setExpandedProductId(null); // Close expanded card when changing category
                }}
                className={`px-3 py-2 text-sm font-medium rounded-xl transition-all duration-200 border-2 flex-1 max-w-[11.25rem] min-w-[8.75rem] 
                ${selectedCategory === category
                    ? 'bg-green-500 text-white border-green-500 shadow-md transform scale-[1.02]'
                    : 'bg-white text-gray-700 border-gray-300 hover:border-green-500 hover:text-green-500'}
                active:scale-95 touch-manipulation`}
                style={{
                  transform: selectedCategory === category ? 'scale(1.02)' : 'scale(1)',
                  transition: 'all 0.6s cubic-bezier(0.34, 1.56, 0.64, 1)'
                }}
              >
                <motion.span
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ type: "spring", stiffness: 300, damping: 20, delay: index * 0.1 }}
                >
                  {category}
                </motion.span>
              </button>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl p-4 shadow-lg">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <input
              type="text"
              placeholder="Search products..."
              className="p-2 border rounded-xl"
              onChange={(e) => setSearchQuery(e.target.value)}
              value={searchQuery}
            />
            <div className="flex gap-2">
              <input
                type="number"
                placeholder="Min Price"
                className="p-2 border rounded-xl w-full"
                onChange={(e) => setMinPrice(e.target.value ? parseFloat(e.target.value) : null)}
              />
              <input
                type="number"
                placeholder="Max Price"
                className="p-2 border rounded-xl w-full"
                onChange={(e) => setMaxPrice(e.target.value ? parseFloat(e.target.value) : null)}
              />
            </div>
            <select
              className="p-2 border rounded-xl"
              onChange={(e) => setSortOrder(e.target.value)}
              value={sortOrder}
            >
              <option value="">Sort by</option>
              {sortingOptions.map(option => (
                <option key={option} value={option}>{option}</option>
              ))}
            </select>
            <select
              className="p-2 border rounded-xl"
              onChange={(e) => setRatingFilter(e.target.value ? parseInt(e.target.value) : null)}
              value={ratingFilter || ""}
            >
              <option value="">Filter by Rating</option>
              <option value="4">4+ Stars</option>
              <option value="3">3+ Stars</option>
              <option value="2">2+ Stars</option>
            </select>
          </div>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {selectedCategory === "All" && products.length > 0 ? (
          <div className="space-y-6">
            {Object.entries(groupedProducts).map(([category, categoryProducts]) => (
              <div key={category} className="bg-white rounded-xl p-4 shadow-lg">
                <h2 className="text-2xl font-bold text-green-700 mb-4 pb-2 border-b">{category}</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {categoryProducts.map((product, index) => {
                    const globalIndex = products.findIndex(p => p === product);
                    const isExpanded = expandedProductId === globalIndex;
                    const avgRating = calculateAvgRating(product.ratings);
                    
                    return (
                      <motion.div
                        key={`${category}-${index}`}
                        layout
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        transition={{ duration: 0.3 }}
                        className={`relative ${isExpanded ? "col-span-full p-6 border rounded-lg shadow-lg bg-white" : ""}`}
                        onClick={() => handleCardClick(globalIndex)}
                      >
                        <Card className={`p-4 shadow-md rounded-lg cursor-pointer transition-transform ${isExpanded ? "scale-105" : ""}`}>
                          <CardContent>
                            <div className={`relative ${isExpanded ? 'max-w-3xl mx-auto' : ''}`}>
                              <div className={`${isExpanded ? 'bg-gray-50 p-4 rounded-lg shadow-inner' : 'bg-gray-50 rounded-md'}`}>
                                <img
                                  src={product.image || "/images/default-product.jpg"}
                                  alt={product.name}
                                  loading="lazy"
                                  decoding="async"
                                  className={`w-full rounded-md ${
                                    isExpanded 
                                      ? 'max-h-[600px] max-w-full h-auto' 
                                      : 'h-48'
                                  } object-contain`}
                                  style={{ 
                                    objectFit: 'contain',
                                    transform: 'translateZ(0)',
                                    backfaceVisibility: 'hidden'
                                  }}
                                />
                              </div>
                              {product.onSale && (
                                <div className="absolute top-2 right-2 bg-red-500 text-white px-2 py-1 rounded-full text-sm">
                                  Sale!
                                </div>
                              )}
                              <div className="absolute top-2 left-2 bg-green-500 text-white px-2 py-1 rounded-full text-sm">
                                {product.category}
                              </div>
                            </div>
                            <h3 className="text-lg font-bold text-center mt-1">{product.name}</h3>
                            <p className="text-lg font-semibold text-green-600 text-center">₹{product.price}</p>
                            {avgRating !== null && (
                              <div className="flex justify-center items-center gap-1 mt-1">
                                <span>⭐</span>
                                <span>{avgRating.toFixed(1)}</span>
                                <span className="text-gray-500">({product.ratings?.length || 0} reviews)</span>
                              </div>
                            )}
                            {isExpanded && (
                              <div className="mt-4">
                                <p className="text-sm text-gray-600">{product.description}</p>
                                <p className="mt-2"><strong>Supplier:</strong> {product.supplier}</p>
                                <p><strong>Contact:</strong> {product.contact}</p>
                                {product.contact && (
                                  <Button
                                    className="mt-2 bg-green-500 text-white p-2 rounded-lg"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      window.location.href = `tel:${product.contact}`;
                                    }}
                                  >📞 Call Now</Button>
                                )}
                                <p><strong>Website:</strong> <a href={product.website} target="_blank" rel="noopener noreferrer" className="text-blue-500">{product.website}</a></p>
                                <h3 className="text-xl font-semibold mt-4">Reviews</h3>
                                {product.ratings && product.ratings.length > 0 ? (
                                  product.ratings.map((comment, i) => (
                                    <div key={i} className="border-t pt-2 mt-2">
                                      <p className="font-bold">{comment.name} ⭐ {comment.rating}/5 <span className="text-gray-500">{comment.date}</span></p>
                                      <p className="text-gray-700">{comment.comment}</p>
                                    </div>
                                  ))
                                ) : (
                                  <p className="text-gray-500">No reviews yet</p>
                                )}
                                <Button 
                                  className="mt-4 bg-green-600 text-white px-4 py-2 rounded"
                                  onClick={(e) => e.stopPropagation()}
                                >
                                  Write a Review
                                </Button>
                              </div>
                            )}
                          </CardContent>
                        </Card>
                      </motion.div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        ) : products.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-6">
            {products.map((product, index) => {
              const isExpanded = expandedProductId === index;
              const avgRating = calculateAvgRating(product.ratings);
              
              return (
                <motion.div
                  key={index}
                  layout
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.3 }}
                  className={`relative ${isExpanded ? "col-span-full p-6 border rounded-lg shadow-lg bg-white" : ""}`}
                  onClick={() => handleCardClick(index)}
                >
                  <Card className={`p-4 shadow-md rounded-lg cursor-pointer transition-transform ${isExpanded ? "scale-105" : ""}`}>
                    <CardContent>
                      <div className={`relative ${isExpanded ? 'max-w-3xl mx-auto' : ''}`}>
                        <div className={`${isExpanded ? 'bg-gray-50 p-4 rounded-lg shadow-inner' : 'bg-gray-50 rounded-md'}`}>
                          <img
                            src={product.image || "/images/default-product.jpg"}
                            alt={product.name}
                            loading="lazy"
                            decoding="async"
                            className={`w-full rounded-md ${
                              isExpanded 
                                ? 'max-h-[600px] max-w-full h-auto' 
                                : 'h-48'
                            } object-contain`}
                            style={{ 
                              objectFit: 'contain',
                              transform: 'translateZ(0)',
                              backfaceVisibility: 'hidden'
                            }}
                          />
                        </div>
                        {product.onSale && (
                          <div className="absolute top-2 right-2 bg-red-500 text-white px-2 py-1 rounded-full text-sm">
                            Sale!
                          </div>
                        )}
                      </div>
                      <h3 className="text-lg font-bold text-center">{product.name}</h3>
                      <p className="text-lg font-semibold text-green-600 text-center">₹{product.price}</p>
                      {avgRating !== null && (
                        <div className="flex justify-center items-center gap-1 mt-1">
                          <span>⭐</span>
                          <span>{avgRating.toFixed(1)}</span>
                          <span className="text-gray-500">({product.ratings?.length || 0} reviews)</span>
                        </div>
                      )}
                      {isExpanded && (
                        <div className="mt-4">
                          <p className="text-sm text-gray-600">{product.description}</p>
                          <p className="mt-2"><strong>Supplier:</strong> {product.supplier}</p>
                          <p><strong>Contact:</strong> {product.contact}</p>
                          {product.contact && (
                            <Button
                              className="mt-2 bg-green-500 text-white p-2 rounded-lg"
                              onClick={(e) => {
                                e.stopPropagation();
                                window.location.href = `tel:${product.contact}`;
                              }}
                            >📞 Call Now</Button>
                          )}
                          <p><strong>Website:</strong> <a href={product.website} target="_blank" rel="noopener noreferrer" className="text-blue-500">{product.website}</a></p>
                          <h3 className="text-xl font-semibold mt-4">Reviews</h3>
                          {product.ratings && product.ratings.length > 0 ? (
                            product.ratings.map((comment, i) => (
                              <div key={i} className="border-t pt-2 mt-2">
                                <p className="font-bold">{comment.name} ⭐ {comment.rating}/5 <span className="text-gray-500">{comment.date}</span></p>
                                <p className="text-gray-700">{comment.comment}</p>
                              </div>
                            ))
                          ) : (
                            <p className="text-gray-500">No reviews yet</p>
                          )}
                          <Button 
                            className="mt-4 bg-green-600 text-white px-4 py-2 rounded"
                            onClick={(e) => e.stopPropagation()}
                          >
                            Write a Review
                          </Button>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-10">
            <p className="text-gray-500 text-lg">No products match your filters</p>
            <Button 
              className="mt-4 bg-green-600 text-white px-4 py-2 rounded"
              onClick={() => {
                setSearchQuery("");
                setMinPrice(null);
                setMaxPrice(null);
                setRatingFilter(null);
                setSelectedFilters([]);
              }}
            >
              Clear Filters
            </Button>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default Marketplace;