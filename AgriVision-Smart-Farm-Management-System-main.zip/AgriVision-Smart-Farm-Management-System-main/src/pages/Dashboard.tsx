const Dashboard = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      <div className="bg-white/80 backdrop-blur-xl rounded-2xl shadow-[0_4px_20px_rgb(0,0,0,0.03)] p-6 hover:shadow-[0_4px_25px_rgb(0,0,0,0.05)] transition-all duration-200 border border-gray-200/50">
        <h3 className="text-lg font-semibold text-gray-800 mb-2">Quick Actions</h3>
        <p className="text-gray-600">Access frequently used features and tools</p>
      </div>
      <div className="bg-white/80 backdrop-blur-xl rounded-2xl shadow-[0_4px_20px_rgb(0,0,0,0.03)] p-6 hover:shadow-[0_4px_25px_rgb(0,0,0,0.05)] transition-all duration-200 border border-gray-200/50">
        <h3 className="text-lg font-semibold text-gray-800 mb-2">Recent Activity</h3>
        <p className="text-gray-600">View your latest farm management activities</p>
      </div>
      <div className="bg-white/80 backdrop-blur-xl rounded-2xl shadow-[0_4px_20px_rgb(0,0,0,0.03)] p-6 hover:shadow-[0_4px_25px_rgb(0,0,0,0.05)] transition-all duration-200 border border-gray-200/50">
        <h3 className="text-lg font-semibold text-gray-800 mb-2">Insights</h3>
        <p className="text-gray-600">Key metrics and recommendations</p>
      </div>
    </div>
  )
}

export default Dashboard