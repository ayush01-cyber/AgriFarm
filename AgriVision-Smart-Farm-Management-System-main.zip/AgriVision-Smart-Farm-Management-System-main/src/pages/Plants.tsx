import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { landSizeData } from '../data/landSizeData';
import { LandSizeData } from '../types/types';

const Plants = () => {
  const [selectedLandSize, setSelectedLandSize] = useState(() => {
    // Try to get the saved land size from localStorage, default to '< 10' if not found
    const savedLandSize = localStorage.getItem('selectedLandSize');
    return savedLandSize || '< 10';
  });

  // Save the selection to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('selectedLandSize', selectedLandSize);
  }, [selectedLandSize]);

  const selectedData = landSizeData.find((data: LandSizeData) => data.size.en === selectedLandSize);
  const language: 'en' | 'hi' = 'en';

  const translations = {
    landSizeSelection: language === 'en' ? (
      <span className="font-bold text-black">What is your land size? (acres)</span>
    ) : (
      <span className="font-bold text-black">आपकी जमीन का एकड़ क्या है? (एकड़)</span>
    ),
    recommendedCrops: language === 'en' ? "Recommended Crops" : "अनुशंसित फसलें",
    rotationSuggestions: language === 'en' ? "Crop Rotation Suggestions" : "फसल चक्र सुझाव",
    mixedCropping: language === 'en' ? "Mixed Cropping Options" : "मिश्रित खेती विकल्प",
    benefits: language === 'en' ? "Benefits" : "लाभ"
  };

  return (
    <div className="container mx-auto px-2 py-4 max-w-7xl">
      {/* Header Section */}
      <div className="mb-4 space-y-3">
        <div className="bg-white rounded-xl p-4 shadow-lg">
          <h2 className="text-xl font-semibold mb-3 text-gray-800">{translations.landSizeSelection}</h2>
          <div className="flex gap-2 overflow-x-auto hide-scrollbar pb-1 justify-center">
            {landSizeData.map((data: LandSizeData, index) => (
              <button
                key={data.size[language]}
                onClick={() => setSelectedLandSize(data.size.en)}
                className={`px-3 py-2 text-sm font-medium rounded-xl transition-all duration-200 border-2 flex-1 max-w-[11.25rem] min-w-[8.75rem]
                  ${selectedLandSize === data.size.en
                    ? 'bg-green-500 text-white border-green-500 shadow-md transform scale-[1.02]'
                    : 'bg-white text-gray-700 border-gray-300 hover:border-green-500 hover:text-green-500'}
                  active:scale-95 touch-manipulation`}
                style={{
                  transform: selectedLandSize === data.size.en ? 'scale(1.02)' : 'scale(1)',
                  transition: 'all 0.6s cubic-bezier(0.34, 1.56, 0.64, 1)'
                }}
              >
                <motion.span
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{
                    type: 'spring',
                    stiffness: 300,
                    damping: 20,
                    delay: index * 0.1
                  }}
                >
                  {data.size[language]}
                </motion.span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Grid */}
      <AnimatePresence mode="wait">
        {selectedData && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <motion.div
              initial={{ x: -20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.5 }}
              whileHover={{ scale: 1.02 }}
              className="bg-gradient-to-br from-purple-500/10 to-blue-500/10 backdrop-blur-md rounded-xl p-4 shadow-lg border border-purple-100/50"
            >
              <h3 className="text-lg font-semibold text-gray-900 mb-2 text-center">{translations.recommendedCrops}</h3>
              <p className="text-gray-700 leading-relaxed whitespace-pre-line text-left">{selectedData.recommendedCrops[language]}</p>
            </motion.div>

            <motion.div
              initial={{ x: 20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.6 }}
              whileHover={{ scale: 1.02 }}
              className="bg-gradient-to-br from-emerald-500/10 to-green-500/10 backdrop-blur-md rounded-xl p-4 shadow-lg border border-emerald-100/50"
            >
              <h3 className="text-lg font-semibold text-gray-900 mb-2 text-center">{translations.rotationSuggestions}</h3>
              <p className="text-gray-700 leading-relaxed whitespace-pre-line text-left">{selectedData.rotationSuggestions[language]}</p>
            </motion.div>

            <motion.div
              initial={{ x: -20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.7 }}
              whileHover={{ scale: 1.02 }}
              className="bg-gradient-to-br from-rose-500/10 to-pink-500/10 backdrop-blur-md rounded-xl p-4 shadow-lg border border-rose-100/50"
            >
              <h3 className="text-lg font-semibold text-gray-900 mb-2 text-center">{translations.mixedCropping}</h3>
              <p className="text-gray-700 leading-relaxed whitespace-pre-line text-left">{selectedData.mixedCropping[language]}</p>
            </motion.div>

            <motion.div
              initial={{ x: 20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.8 }}
              whileHover={{ scale: 1.02 }}
              className="bg-gradient-to-br from-amber-500/10 to-orange-500/10 backdrop-blur-md rounded-xl p-4 shadow-lg border border-amber-100/50"
            >
              <h3 className="text-lg font-semibold text-gray-900 mb-2 text-center">{translations.benefits}</h3>
              <p className="text-gray-700 leading-relaxed whitespace-pre-line text-left">{selectedData.benefits[language]}</p>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default Plants;