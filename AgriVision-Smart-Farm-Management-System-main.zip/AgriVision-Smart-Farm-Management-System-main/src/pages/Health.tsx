import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import SafetyTrainingPortal from '../components/SafetyTraining/SafetyTrainingPortal';
import PPETracker from '../components/PPE/PPETracker';
import ChemicalSafetyPortal from '../components/ChemicalSafety/ChemicalSafetyPortal';
import SafetyChecklistPortal from '../components/SafetyChecklist/SafetyChecklistPortal';
import { HealthTab } from '../types/health';

const Health: React.FC = () => {
  // Define available tabs - partners can add more tabs here
  const tabs: HealthTab[] = [
    {
      id: 'safety-checklist',
      label: 'Safety Checklist',
      component: SafetyChecklistPortal
    },
    {
      id: 'safety-training',
      label: 'Safety Training',
      component: SafetyTrainingPortal
    },
    {
      id: 'ppe-tracker',
      label: 'PPE Tracker',
      component: PPETracker
    },
    {
      id: 'chemical-safety',
      label: 'Chemical Safety Management',
      component: ChemicalSafetyPortal
    }
    // Partners can add more tabs like:
    // {
    //   id: 'health-monitoring',
    //   label: 'Health Monitoring',
    //   component: HealthMonitoring
    // }
  ];

  const [activeTab, setActiveTab] = useState<string>(() => {
    const savedTab = localStorage.getItem('healthActiveTab');
    return savedTab && tabs.find(t => t.id === savedTab) ? savedTab : tabs[0].id;
  });

  // Save active tab to localStorage whenever it changes
  React.useEffect(() => {
    localStorage.setItem('healthActiveTab', activeTab);
  }, [activeTab]);

  const getCurrentTab = () => {
    const tab = tabs.find(t => t.id === activeTab);
    if (!tab) return null;
    const Component = tab.component;
    return <Component />;
  };

  return (
    <div className="max-w-7xl mx-auto px-2 sm:px-6 lg:px-8 py-4 min-h-screen">

      {/* Tab Navigation - Scrollable on mobile */}
      <div className="-mx-2 px-2 sm:-mx-4 sm:px-4 mb-6 overflow-x-auto hide-scrollbar">
        <div className="flex gap-2 sm:gap-3 sm:justify-center min-w-max pb-2">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-3 sm:px-6 py-3 text-sm font-medium rounded-2xl transition-all duration-200 border-2 min-w-[120px]
                ${activeTab === tab.id
                  ? 'bg-green-500 text-white border-green-500 shadow-md transform scale-[1.02]'
                  : 'bg-white text-gray-700 border-gray-300 hover:border-green-500 hover:text-green-500'}
                active:scale-95 touch-manipulation`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Tab Content */}
      <AnimatePresence mode="wait">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.3, ease: "easeInOut", stiffness: 100 }}
          className="bg-white rounded-2xl p-2 sm:p-6 shadow-lg max-w-5xl mx-auto"
        >
          {getCurrentTab()}
        </motion.div>
      </AnimatePresence>
    </div>
  );
};

export default Health;