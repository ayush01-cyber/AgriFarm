import { LandSizeData } from '../types/types';

export const landSizeData: LandSizeData[] = [
    {
      size: {
        en: "Less than 10",
        hi: "10 से कम"
      },
      recommendedCrops: {
        en: "• Soybean: Ideal for small plots, high protein content\n• Wheat: Reliable winter crop, good market value\n• Seasonal vegetables: Quick returns, high value per acre",
        hi: "• सोयाबीन: छोटे खेतों के लिए आदर्श, उच्च प्रोटीन सामग्री\n• गेहूं: विश्वसनीय सर्दियों की फसल, अच्छा बाजार मूल्य\n• मौसमी सब्जियां: त्वरित रिटर्न, प्रति एकड़ उच्छ मूल्य"
      },
      rotationSuggestions: {
        en: "• Primary Rotation:\n  - Year 1: Soybean (Kharif) → Wheat (Rabi)\n  - Year 2: Fallow (soil recovery)\n\n• Alternative Rotation:\n  - Year 1: Maize (Kharif) → Chickpea (Rabi)\n  - Year 2: Green manure crops",
        hi: "• प्राथमिक रोटेशन:\n  - वर्ष 1: सोयाबीन (खरीफ) → गेहूं (रबी)\n  - वर्ष 2: परती (मिट्टी की रिकवरी)\n\n• वैकल्पिक रोटेशन:\n  - वर्ष 1: मक्का (खरीफ) → चना (रबी)\n  - वर्ष 2: हरी खाद की फसलें"
      },
      mixedCropping: {
        en: "• Soybean + Maize Intercropping:\n  - Row ratio: 4:2\n  - Benefits: Better land utilization\n  - Increased total yield per acre\n\n• Border Cropping:\n  - Main crop: Soybean\n  - Border: Maize or Sorghum",
        hi: "• सोयाबीन + मक्का अंतर्वर्ती खेती:\n  - पंक्ति अनुपात: 4:2\n  - लाभ: बेहतर भूमि उपयोग\n  - प्रति एकड़ कुल उपज में वृद्धि\n\n• सीमा खेती:\n  - मुख्य फसल: सोयाबीन\n  - सीमा: मक्का या ज्वार"
      },
      benefits: {
        en: "• Soil Benefits:\n  - Improved nitrogen fixation\n  - Enhanced soil structure\n  - Better water retention\n\n• Economic Benefits:\n  - Diversified income sources\n  - Reduced risk of crop failure\n  - Lower input costs",
        hi: "• मिट्टी के लाभ:\n  - बेहतर नाइट्रोजन स्थिरीकरण\n  - बेहतर मिट्टी की संरचना\n  - बेहतर जल धारण\n\n• आर्थिक लाभ:\n  - विविध आय स्रोत\n  - फसल विफलता का कम जोखिम\n  - कम इनपुट लागत"
      }
    },
    {
      size: {
        en: "Between 10-20",
        hi: "10-20 के बीच"
      },
      recommendedCrops: {
        en: "• Soybean: Main kharif season crop\n• Wheat: Primary rabi season crop\n• Chickpea: Nitrogen-fixing winter crop\n• Seasonal vegetables: For market diversity",
        hi: "• सोयाबीन: मुख्य खरीफ मौसम की फसल\n• गेहूं: प्राथमिक रबी मौसम की फसल\n• चना: नाइट्रोजन स्थिरीकरण करने वाली सर्दियों की फसल\n• मौसमी सब्जियां: बाजार विविधता के लिए"
      },
      rotationSuggestions: {
        en: "• Primary Rotation:\n  - Year 1: Soybean → Wheat → Chickpea\n  - Year 2: Soybean → Wheat → Lentil\n\n• Alternative Rotation:\n  - Include green manure crops\n  - Short-duration vegetables between seasons",
        hi: "• प्राथमिक रोटेशन:\n  - वर्ष 1: सोयाबीन → गेहूं → चना\n  - वर्ष 2: सोयाबीन → गेहूं → मसूर\n\n• वैकल्पिक रोटेशन:\n  - हरी खाद की फसलें शामिल करें\n  - मौसमों के बीछ अल्पकालिक सब्जियां"
      },
      mixedCropping: {
        en: "• Row Arrangements:\n  - Soybean + Sorghum (border rows)\n  - Wheat + Mustard (5:1 row ratio)\n\n• Intercropping Benefits:\n  - Improved pest resistance\n  - Better resource utilization\n  - Enhanced soil coverage",
        hi: "• पंक्ति व्यवस्था:\n  - सोयाबीन + ज्वार (सीमा पंक्तियां)\n  - गेहूं + सरसों (5:1 पंक्ति अनुपात)\n\n• अंतर्वर्ती खेती के लाभ:\n  - बेहतर कीट प्रतिरोधक क्षमता\n  - बेहतर संसाधन उपयोग\n  - बेहतर मिट्टी कवरेज"
      },
      benefits: {
        en: "• Agronomic Benefits:\n  - Enhanced resource utilization\n  - Natural pest control\n  - Improved soil fertility\n\n• Economic Benefits:\n  - Stable income flow\n  - Market flexibility\n  - Risk distribution",
        hi: "• कृषि लाभ:\n  - बेहतर संसाधन उपयोग\n  - प्राकृतिक कीट नियंत्रण\n  - बेहतर मिट्टी उर्वरता\n\n• आर्थिक लाभ:\n  - स्थिर आय प्रवाह\n  - बाजार लचीलापन\n  - जोखिम वितरण"
      }
    },
    {
      size: {
        en: "Between 20-50",
        hi: "20-50 के बीच"
      },
      recommendedCrops: {
        en: "• Major Crops:\n  - Soybean: Large-scale cultivation\n  - Wheat: Mechanized farming\n  - Chickpea: Winter legume\n  - Mustard: Oil crop\n  - Vegetables: Market-oriented production",
        hi: "• प्रमुख फसलें:\n  - सोयाबीन: बड़े पैमाने पर खेती\n  - गेहूं: मशीनीकृत खेती\n  - चना: सर्दियों की फलियां\n  - सरसों: तेल की फसल\n  - सब्जियां: बाजार उन्मुख उत्पादन"
      },
      rotationSuggestions: {
        en: "• Comprehensive Rotation:\n  - Year 1: Soybean → Wheat\n  - Year 2: Chickpea → Mustard\n  - Year 3: Green manure\n\n• Alternative Rotation:\n  - Maize → Wheat → Moong\n  - Focus on soil health",
        hi: "• व्यापक रोटेशन:\n  - वर्ष 1: सोयाबीन → गेहूं\n  - वर्ष 2: चना → सरसों\n  - वर्ष 3: हरी खाद\n\n• वैकल्पिक रोटेशन:\n  - मक्का → गेहूं → मूंग\n  - मिट्टी की सेहत पर ध्यान दें"
      },
      mixedCropping: {
        en: "• Major Combinations:\n  - Maize + Pigeon Pea (Arhar)\n  - Wheat + Chickpea (relay)\n\n• Implementation:\n  - Strip cropping\n  - Alley cropping\n  - Border cropping",
        hi: "• प्रमुख संयोजन:\n  - मक्का + अरहर\n  - गेहूं + चना (रिले)\n\n• कार्यान्वयन:\n  - पट्टी खेती\n  - गलियारा खेती\n  - सीमा खेती"
      },
      benefits: {
        en: "• Production Benefits:\n  - Optimized land use\n  - Better risk management\n  - Improved soil health\n\n• Management Benefits:\n  - Efficient resource use\n  - Labor distribution\n  - Market flexibility",
        hi: "• उत्पादन लाभ:\n  - अनुकूलित भूमि उपयोग\n  - बेहतर जोखिम प्रबंधन\n  - बेहतर मिट्टी स्वास्थ्य\n\n• प्रबंधन लाभ:\n  - कुशल संसाधन उपयोग\n  - श्रम वितरण\n  - बाजार लचीलापन"
      }
    },
    {
      size: {
        en: "Between 50-100",
        hi: "50-100 के बीच"
      },
      recommendedCrops: {
        en: "• Major Crops:\n  - Soybean: Main kharif crop\n  - Wheat: Primary rabi crop\n  - Chickpea: Winter legume\n\n• Commercial Crops:\n  - Mustard: Oilseed\n  - Vegetables: Onion, Garlic, Coriander",
        hi: "• प्रमुख फसलें:\n  - सोयाबीन: मुख्य खरीफ फसल\n  - गेहूं: प्राथमिक रबी फसल\n  - चना: सर्दियों की फलियां\n\n• व्यावसायिक फसलें:\n  - सरसों: तेल की फसल\n  - सब्जियां: प्याज, लहसुन, धनिया"
      },
      rotationSuggestions: {
        en: "• Long-term Rotation:\n  - Cycle 1: Soybean → Wheat → Chickpea\n  - Cycle 2: Mustard → Fallow\n\n• Alternative Rotation:\n  - Maize → Wheat → Moong\n  - Vegetables (seasonal)",
        hi: "• दीर्घकालिक रोटेशन:\n  - चक्र 1: सोयाबीन → गेहूं → चना\n  - चक्र 2: सरसों → परती\n\n• वैकल्पिक रोटेशन:\n  - मक्का → गेहूं → मूंग\n  - सब्जियां (मौसमी)"
      },
      mixedCropping: {
        en: "• Complex Systems:\n  - Soybean + Maize + Pigeon Pea\n  - Wheat + Mustard + Gram\n\n• Spatial Arrangements:\n  - Strip cropping\n  - Relay cropping\n  - Border management",
        hi: "• जटिल प्रणाली:\n  - सोयाबीन + मक्का + अरहर\n  - गेहूं + सरसों + चना\n\n• स्थानिक व्यवस्था:\n  - पट्टी खेती\n  - रिले खेती\n  - सीमा प्रबंधन"
      },
      benefits: {
        en: "• System Benefits:\n  - Integrated farming approach\n  - Optimized land utilization\n  - Improved soil fertility\n\n• Economic Benefits:\n  - Multiple income streams\n  - Market flexibility\n  - Risk mitigation",
        hi: "• प्रणाली लाभ:\n  - एकीकृत खेती दृष्टिकोण\n  - अनुकूलित भूमि उपयोग\n  - बेहतर मिट्टी उर्वरता\n\n• आर्थिक लाभ:\n  - बहुसंख्यक आय धाराएं\n  - बाजार लचीलापन\n  - जोखिम कम करना"
      }
    },
    {
      size: {
        en: "More than 100",
        hi: "100 से अधिक"
      },
      recommendedCrops: {
        en: "• Field Crops:\n  - Soybean: Large-scale production\n  - Wheat: Mechanized farming\n  - Pulses: Soil improvement\n\n• Commercial Crops:\n  - Oilseeds: Market value\n  - Horticultural crops: High returns",
        hi: "• खेत की फसलें:\n  - सोयाबीन: बड़े पैमाने पर उत्पादन\n  - गेहूं: मशीनीकृत खेती\n  - दलहन: मिट्टी सुधार\n\n• व्यावसायिक फसलें:\n  - तेल की फसलें: बाजार मूल्य\n  - बागवानी फसलें: उच्छ रिटर्न"
      },
      rotationSuggestions: {
        en: "• Advanced Rotation System:\n  - Year 1-2: Cereals (Wheat/Maize)\n  - Year 3-4: Pulses (Soybean/Chickpea)\n  - Year 5: Oilseeds\n  - Year 6-7: Cover crops/Green manure\n\n• Livestock Integration:\n  - Fodder crops in rotation\n  - Pasture management",
        hi: "• उन्नत रोटेशन प्रणाली:\n  - वर्ष 1-2: अनाज (गेहूं/मक्का)\n  - वर्ष 3-4: दलहन (सोयाबीन/चना)\n  - वर्ष 5: तेल की फसलें\n  - वर्ष 6-7: कवर फसलें/हरी खाद\n\n• पशुपालन एकीकरण:\n  - रोटेशन में चारा फसलें\n  - चारागाह प्रबंधन"
      },
      mixedCropping: {
        en: "• Agroforestry Integration:\n  - Tree crops on boundaries\n  - Alley cropping systems\n  - Silvopasture\n\n• Crop Combinations:\n  - Multiple crop layers\n  - Seasonal variations\n  - Resource optimization",
        hi: "• वानिकी एकीकरण:\n  - सीमाओं पर वृक्ष फसलें\n  - गलियारा खेती प्रणाली\n  - सिल्वोपास्चर\n\n• फसल संयोजन:\n  - बहुस्तरीय फसलें\n  - मौसमी भिन्नताएं\n  - संसाधन अनुकूलन"
      },
      benefits: {
        en: "• Sustainability Benefits:\n  - Enhanced biodiversity\n  - Improved soil health\n  - Carbon sequestration\n\n• Management Benefits:\n  - Efficient resource use\n  - Risk distribution\n  - Market adaptability\n\n• Environmental Impact:\n  - Reduced carbon footprint\n  - Wildlife habitat\n  - Water conservation",
        hi: "• स्थिरता लाभ:\n  - बेहतर जैव विविधता\n  - बेहतर मिट्टी स्वास्थ्य\n  - कार्बन सिंक\n\n• प्रबंधन लाभ:\n  - कुशल संसाधन उपयोग\n  - जोखिम वितरण\n  - बाजार अनुकूलन\n\n• पर्यावरणीय प्रभाव:\n  - कम कार्बन फुटप्रिंट\n  - वन्यजीव आवास\n  - जल संरक्षण"
      }
    }
  ];