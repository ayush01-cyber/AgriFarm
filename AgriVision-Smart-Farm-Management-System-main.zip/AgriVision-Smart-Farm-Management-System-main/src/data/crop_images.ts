interface CropImage {
  image: string;
  description: string;
}

export const cropImages: Record<string, CropImage> = {
  "Cotton": {
    image: "https://source.unsplash.com/800x600/?cotton+plant",
    description: "A soft, fluffy staple fiber that grows in a boll around the seeds of cotton plants."
  },
  "Sorghum": {
    image: "https://source.unsplash.com/800x600/?sorghum",
    description: "A nutrient-rich grain crop that's drought-resistant and versatile."
  },
  "Pigeon Pea": {
    image: "https://source.unsplash.com/800x600/?pea+plant",
    description: "A legume crop that improves soil fertility and provides protein-rich seeds."
  },
  "Wheat": {
    image: "https://source.unsplash.com/800x600/?wheat+field",
    description: "A cereal grain that's a worldwide staple food."
  },
  "Chickpea": {
    image: "https://source.unsplash.com/800x600/?chickpea+plant",
    description: "A legume crop rich in protein and beneficial for soil health."
  },
  "Soybean": {
    image: "https://source.unsplash.com/800x600/?soybean+plant",
    description: "A legume that's a major source of protein and oil."
  },
  "Millets": {
    image: "https://source.unsplash.com/800x600/?millet+plant",
    description: "Small-seeded grasses that are highly nutritious and drought-resistant."
  },
  "Groundnut": {
    image: "https://source.unsplash.com/800x600/?peanut+plant",
    description: "A legume crop that produces protein-rich nuts underground."
  },
  "Red Gram": {
    image: "https://source.unsplash.com/800x600/?red+gram",
    description: "A pulse crop that's rich in protein and adapts well to different soils."
  },
  "Maize": {
    image: "https://source.unsplash.com/800x600/?corn+plant",
    description: "A versatile grain crop used for food, feed, and industrial products."
  },
  "Vegetables": {
    image: "https://source.unsplash.com/800x600/?vegetable+garden",
    description: "Various vegetable crops suitable for the current soil conditions."
  },
  "Pulses": {
    image: "https://source.unsplash.com/800x600/?pulses+plants",
    description: "Leguminous crops that are rich in protein and improve soil fertility."
  }
};
