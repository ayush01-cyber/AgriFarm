export interface SafetyGuide {
  id: string;
  title: string;
  description: string;
  fileUrl: string;
  fileSize: string;
  language: string;
  category: string;
}

export const safetyGuides: SafetyGuide[] = [
  {
    id: 'guide-1',
    title: 'Farm Fire Safety Guide',
    description: 'Important safety instructions for fire prevention during crop harvesting',
    fileUrl: '/guides/fire-safety-guide.pdf',
    fileSize: '2.5 MB',
    language: 'English',
    category: 'Fire Safety'
  },
  {
    id: 'guide-2',
    title: 'Agricultural Equipment Safety Manual',
    description: 'Detailed manual for safe operation of tractors and other farming equipment',
    fileUrl: '/guides/machinery-manual.pdf',
    fileSize: '4.1 MB',
    language: 'English',
    category: 'Equipment Safety'
  },
  {
    id: 'guide-3',
    title: 'Seasonal Safety Guidelines',
    description: 'Safety precautions for farming during different seasons',
    fileUrl: '/guides/seasonal-safety.pdf',
    fileSize: '3.2 MB',
    language: 'English',
    category: 'Seasonal Safety'
  }
];

export interface VideoTutorial {
  id: string;
  title: string;
  description: string;
  videoUrl: string;
  duration: string;
  language: string;
  thumbnail: string;
}

export const videoTutorials: VideoTutorial[] = [
  {
    id: 'video-1',
    title: 'Safe Spraying Techniques',
    description: 'Detailed video on safety measures during pesticide spraying',
    videoUrl: '/videos/safe-spraying.mp4',
    duration: '15:30',
    language: 'English',
    thumbnail: '/thumbnails/spraying.jpg'
  },
  {
    id: 'video-2',
    title: 'Heat Stress Prevention',
    description: 'Health care while working in hot weather conditions',
    videoUrl: '/videos/heat-safety.mp4',
    duration: '12:45',
    language: 'English',
    thumbnail: '/thumbnails/heat-safety.jpg'
  },
  {
    id: 'video-3',
    title: 'Emergency Response Training',
    description: 'Training on handling emergency situations in the field',
    videoUrl: '/videos/emergency-response.mp4',
    duration: '20:15',
    language: 'English',
    thumbnail: '/thumbnails/emergency.jpg'
  }
];
